#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#pragma warning(disable:4996)
void swap(int* lhs, int* rhs)
{
	int t = *lhs;

	*lhs = *rhs;
	*rhs = t;
}
void fullpermutation(int source[], int begin, int end)
{
	int i;
	if (begin >= end)
	{
		for (i = 0; i < end; i++)
			printf("%d", source[i]);
		printf("\n");

	}
	else
	{
		for (i = begin; i < end; i++)
		{
			if (begin != i)
			{
				swap(&source[begin], &source[i]);
			}
			fullpermutation(source, begin + 1, end);
			if (begin != i)
			{
				swap(&source[begin], &source[i]);
			}
		}
	}
}
int main()
{
	int source[30];
	int i;
	char ar;
	char szbuf[20];
	char* pctmp;
	char seps[] = "\n";
	char ch[20];
	FILE* fp;

	fp = fopen("C:\\Users\\Kiang\\Desktop\\20195798yang\\input.txt", "r");
	if (NULL == fp)
	{
		return -1;
	}
	fread(&szbuf, 4, 20, fp);
	fclose(fp);
	pctmp = strtok(szbuf, seps);
	int atoi(const char* pctmp);
	ar = atoi(pctmp);
	for (i = 0; i < ar; i++)
		source[i] = i + 1;
	fullpermutation(source, 0, ar);
	return 0;
}