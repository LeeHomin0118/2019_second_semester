#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int count = 1;

void swap(char* a, char* b) {
	char temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

void print_arr(int index,char *arr,char*fp2) {
	fprintf(fp2, "[%03d] ", count);

	for (int i = 0; i < index; i++) {
		fprintf(fp2, "%c ", arr[i]);
	}
	count++;
	fprintf(fp2,"\n");
}

void permutation(int n, int r, char* arr,char *fp2)
{
	if (r == n) {
		print_arr(n+1,arr,fp2);
		return;
	}
	for (int i = r; i <= n; i++) {
		swap(&arr[r], &arr[i]);
		permutation(n, r + 1, arr,fp2);
		swap(&arr[r], &arr[i]);
	}
}

int main(int argc, char* argv[])
{
	FILE* fp1, * fp2;

	char str[20];

	if ((fp1 = fopen(argv[1], "r")) == NULL) {
		printf("fail to open file.");
		return 0;
	}
	
	if ((fp2 = fopen(argv[2], "wt")) == NULL) {
		printf("fail to create file for write.");
		return 0;
	}
		
	int num = 0;
	int index = 0;
	int flag = 0;
	int count = 0;
	char* word = NULL;

	while (fgets(str, sizeof(str), fp1)) 
	{
		if (flag == 0) {
			num = atoi(str);
			flag++;
			word = (char*)malloc(sizeof(char) * num);
		}

		else if(flag != 0) {
			word[index] = str[0];
			index++;
		}
	}

	permutation(num-1,0, word,fp2);

	
	fprintf(fp2, "----------------------!!!!!!\n");
	fprintf(fp2, "Hyo Chang Yoo\n");
	fprintf(fp2, "Student ID : 20190551\n");
	fprintf(fp2, "----------------------!!!!!!\n");

	fclose(fp1);
	fclose(fp2);

	return 0;
}