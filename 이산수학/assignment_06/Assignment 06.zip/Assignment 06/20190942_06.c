#define _CRT_SECURE_NO_WARNINGS
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void permutation(FILE *fpo, char* sorted, char* unsorted, int ordered_element, int cardi);
void array_copy(char *dest, char *dptr, int cardi);

int count = 1;

int main(int argc, char *argv[]) //argv[1]�� input, argv[2]�� output
{
	FILE *fpi;
    FILE *fpo;
    fpi = fopen(argv[1], "r");
    fpo = fopen(argv[2], "w");
	int i;
	int cardi;
	char* empty;
	char* element; //�ִ� 6��
	//input.txt�� �о ���� ����� �迭�� �����ϱ�
	fscanf(fpi ,"%d", &cardi);
	fscanf(fpi ,"%d", &cardi); //�迭 ������ ����
	//�迭 ���Ҹ� �����ϱ�

	empty = (char *)calloc(cardi, sizeof(char));
	element = (char *)calloc(cardi, sizeof(char));

	for (i = 0; i < cardi; i++)
	{
		fscanf(fpi ,"%c", &element[i]);
		fgetc(fpi);
	}

	permutation(fpo, empty, element, 0, cardi);

	free(empty);
	free(element);

	//print signiture
	printf("\n\n\n");
	printf("     ( ||| )\n");
	printf("   ( ||||| )\n");
	printf("   ( �ڶ󳪴� )\n");
	printf("   (( 20190942 ))\n");
	printf("   ((( �ڰ��� )))\n");
	printf("   (( ���� ))\n");
	printf("    ( ||||| )\n");
	for (i = 0; i < 8; i++)
	{
		printf("	|||||\n");
	}
	printf("\n20190942 Park Gwan Bin\n");

	fprintf(fpo,"\n\n\n");
	fprintf(fpo,"     ( ||| )\n");
	fprintf(fpo,"   ( ||||| )\n");
	fprintf(fpo,"   ( �ڶ󳪴� )\n");
	fprintf(fpo,"   (( 20190942 ))\n");
	fprintf(fpo,"   ((( �ڰ��� )))\n");
	fprintf(fpo,"   (( ���� ))\n");
	fprintf(fpo,"    ( ||||| )\n");
	for (i = 0; i < 8; i++)
	{
		fprintf(fpo,"      |||||\n");
	}

	return 0;
}

void permutation(FILE *fpo, char* sorted, char* unsorted, int ordered_element, int cardi)
{
	char* l_sorted;
	char* l_unsorted;
	l_sorted = (char *)calloc(cardi, sizeof(char));
	l_unsorted = (char *)calloc(cardi, sizeof(char));
	array_copy(l_sorted, sorted, cardi);
	array_copy(l_unsorted, unsorted, cardi);

	if (ordered_element < cardi) //recursive step
	{
		for (int i = 0; i < cardi; i++)
		{
			if (l_unsorted[i] != 0)
			{
				//unsorted���Ҹ� sorted�� �ű��
				l_sorted[ordered_element] = l_unsorted[i];
				l_unsorted[i] = 0;
				//ȣ��
				permutation(fpo, l_sorted, l_unsorted, ordered_element + 1, cardi);
				//�ٸ� �� ã��
				l_unsorted[i] = l_sorted[ordered_element];
				l_sorted[ordered_element] = 0;
			}
		}
	}
	else //basis step
	{
		fprintf(fpo, "[%03d] ", count);
		for (int i = 0; i < cardi; i++) fprintf(fpo, "%c ", l_sorted[i]);
		count++;
		fprintf(fpo, "\n");
	}
}

void array_copy(char *dest, char *dptr, int cardi)
{
	for (int i = 0; i < cardi; i++)
	{
		dest[i] = dptr[i]; //����
	}
}
