#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma warning(disable:4996)
#define MAX 100

int Factorial(int n)
{
	if (n > 1)
		return n * Factorial(n - 1);
	else
		return n;
}
int main(int argc, char* argv[])
{
	FILE * fp1 = fopen(argv[1], "rt");
	if (fp1 == NULL)
	{
		printf("fail to open file");
		return -1;
	}
	FILE * fp2 = fopen(argv[2], "wt");
	if (fp2 == NULL)
	{
		printf("fail to wirte file");
		return -1;
	}
	char temp[MAX];
	int m = atoi(fgets(temp, MAX, fp1));
	char* CA = malloc(m * sizeof(char));
	char* CA2 = malloc(m * sizeof(char));
	char* CA3 = malloc(m * sizeof(char));
	char* CA4 = malloc(m * sizeof(char));
	char tem;
	for (int i = 0; i < m; i++)
	{
		fgets(temp, MAX, fp1);
		CA[i] = temp[0];
	}
	strcpy(CA2, CA);
	strcpy(CA3, CA);
	strcpy(CA4, CA);
	if (m == 1)
	{
		fprintf(fp2,"[001] %c", CA[0]);
	}


	if (m == 2)
	{
		for (int i = 0; i < Factorial(m);i++)
		{
			fprintf(fp2,"[%03d] ", i + 1);
			for (int j = 0; j < m; j++)
			{
				fprintf(fp2,"%c", CA[j]);
			}
			if (i % 2 != 0 || i == 0)
			{
				CA[m - 1] = CA2[m - 2];
				CA[m - 2] = CA2[m - 1];
			}
			fprintf(fp2,"\n");
		}
	}
	if (m == 3)
	{
		for (int i = 0; i < Factorial(m);i++)
		{
			fprintf(fp2,"[%03d] ", i + 1);
			for (int j = 0; j < m; j++)
			{
				fprintf(fp2,"%c ", CA[j]);
			}
			if ((i + 1) % 2 != 0 || i == 0)
			{
				tem = CA[m - 1];
				CA[m - 1] = CA[m - 2];
				CA[m - 2] = tem;
			}
			else
			{
				strcpy(CA, CA2);
				tem = CA[m - 3];
				CA[m - 3] = CA[m - 3 + ((i + 1) / 2)];
				CA[m - 3 + ((i + 1) / 2)] = tem;
			}
			fprintf(fp2,"\n");
		}
	}
	if (m == 4)
	{
		for (int i = 0; i < Factorial(m);i++)
		{
			fprintf(fp2,"[%03d] ", i + 1);
			for (int j = 0; j < m; j++)
			{
				fprintf(fp2,"%c ", CA[j]);
			}
			if ((i + 1) % 2 != 0 || i == 0)
			{
				tem = CA[m - 1];
				CA[m - 1] = CA[m - 2];
				CA[m - 2] = tem;
			}
			else if ((i + 1) % 2 == 0 && (i + 1) % 6 != 0)
			{
				strcpy(CA, CA2);
				tem = CA[m - 3];
				CA[m - 3] = CA[m - 3 + (((i + 1)%6) / 2)];
				CA[m - 3 + ((i + 1)%6 / 2)] = tem;
			}
			else
			{
				strcpy(CA, CA2);
				tem = CA[m - 4];
				CA[m - 4] = CA[m - 4 + ((i + 1) / 6)];
				CA[m - 4 + ((i + 1) / 6)] = tem;
				strcpy(CA2, CA);
			}
			fprintf(fp2,"\n");
		}
	}

	if (m == 5)
	{
		for (int i = 0; i < Factorial(m);i++)
		{
			fprintf(fp2,"[%03d] ", i + 1);
			for (int j = 0; j < m; j++)
			{
				fprintf(fp2,"%c ", CA[j]);
			}
			if ((i + 1) % 2 != 0 || i == 0)
			{
				tem = CA[m - 1];
				CA[m - 1] = CA[m - 2];
				CA[m - 2] = tem;
			}
			else if ((i + 1) % 2 == 0 && (i + 1) % 6 != 0  &&(i+1)%24!=0)
			{
				strcpy(CA, CA2);
				tem = CA[m - 3];
				CA[m - 3] = CA[m - 3 + (((i + 1) % 6) / 2)];
				CA[m - 3 + ((i + 1) % 6 / 2)] = tem;
			}
			else if((i+1)%6 ==0 && (i+1) % 24 !=0)
			{
				strcpy(CA, CA2);
				tem = CA[m - 4];
				CA[m - 4] = CA[m - 4 + ((i + 1)%24 / 6)];
				CA[m - 4 + ((i + 1)%24 / 6)] = tem;
				strcpy(CA2, CA);
			}
			else
			{
				strcpy(CA, CA3);
				tem = CA[m - 5];
				CA[m - 5] = CA[m - 5+(i+1)/24];
				CA[m - 5+(i+1)/24] = tem;
				strcpy(CA3, CA);
				strcpy(CA2, CA3);
			}
			fprintf(fp2,"\n");
		}
	}

	if (m == 6)
	{
		for (int i = 0; i < Factorial(m);i++)
		{
			fprintf(fp2,"[%03d] ", i + 1);
			for (int j = 0; j < m; j++)
			{
				fprintf(fp2,"%c ", CA[j]);
			}
			if ((i + 1) % 2 != 0 || i == 0)
			{
				tem = CA[m - 1];
				CA[m - 1] = CA[m - 2];
				CA[m - 2] = tem;
			}
			else if ((i + 1) % 2 == 0 && (i + 1) % 6 != 0 && (i + 1) % 24 != 0 && (i + 1) % 120 != 0)
			{
				strcpy(CA, CA2);
				tem = CA[m - 3];
				CA[m - 3] = CA[m - 3 + (((i + 1) % 6) / 2)];
				CA[m - 3 + ((i + 1) % 6 / 2)] = tem;
			}
			else if ((i + 1) % 6 == 0 && (i + 1) % 24 != 0 &&(i+1)%120 !=0)
			{
				strcpy(CA, CA2);
				tem = CA[m - 4];
				CA[m - 4] = CA[m - 4 + ((i + 1) % 24 / 6)];
				CA[m - 4 + ((i + 1) % 24 / 6)] = tem;
				strcpy(CA2, CA);
			}
			else if( (i+1)%24 == 0 && (i+1)%120 !=0)
			{
				strcpy(CA, CA3);
				tem = CA[m - 5];
				CA[m - 5] = CA[m - 5 + (i + 1)%120 / 24];
				CA[m - 5 + (i + 1)%120 / 24] = tem;
				strcpy(CA3, CA);
				strcpy(CA2, CA3);
			}
			else
			{
				strcpy(CA, CA4);
				tem = CA[m - 6];
				CA[m - 6] = CA[m - 6 + (i+1)/120];
				CA[m -6+(i+1)/120] = tem;
				strcpy(CA4, CA);
				strcpy(CA3, CA4);
				strcpy(CA2, CA4);
			}
			fprintf(fp2,"\n");
		}
	}
	fprintf(fp2, "\n***************\nName : Kim Namju\nStudent ID : 20190270\n***************");
	fclose(fp1);
	fclose(fp2);
}

