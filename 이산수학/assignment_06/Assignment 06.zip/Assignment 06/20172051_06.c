#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//첫 원소 고정 -> 뒷 원소부터 recursive 함수 돌리기
void permutation(char *arr, int count, int first, FILE *fp2){
	static int index = 0;
	
	int i, j;
	char temp;
	char *str_p;
	char *copy;
	
	copy = (char *)calloc(count + 1, sizeof(char));
	
	str_p = (char *)calloc(count * 2 + 1, sizeof(char));
	
	//arr를 복사하여 배열 copy에 저장
	for (i = 0; i < count; i++)
		copy[i] = arr[i];
	
	if (first == count -1){
		for (j = 0, i = 0; j < count; j++, i += 2){
			str_p[i] = arr[j];
			str_p[i+1] = ' ';
		}
		index++;
		fprintf(fp2, "[%03d] %s\n", index, str_p);
	}
	
	else{
		for (j = first; j < count; j++){
			temp = arr[first];
			arr[first] = arr[j];
			arr[j] = temp;
			
			permutation(arr, count, first + 1, fp2);
			
			//arr 복구
			for (i = 0; i < count; i++)
				arr[i] = copy[i];
		}
	}
}

int main(int argc, char *argv[]){
	
	FILE *fp1, *fp2;	//1 입력, 2 출력
	
	char str[30];		//input file 읽을 배열
	int count;			//입력 파일에서 입력 수 개수
	int i;
	//int number = 1;		//출력 개수(경우의 수 개수) : count!
	char *arr;			//input file의 원소들 저장할 배열
	

	if((fp1=fopen(argv[1],"r"))  == NULL){
        printf("cannot open file1");
        return 0;
    }
	
	/*
    if((fp2=fopen(argv[2],"wt")) == NULL){
        printf("cannot open file2");
        return 0;
    }
	*/
	
	fp2 = fopen(argv[2], "w");
	
	if (fgets(str, sizeof(str), fp1) != NULL){
		count = atoi(str);
	}
	
	/*
	for (i = 1; i <= count; i++)
		number *= i;
	*/
	
	arr = (char *)calloc(count + 1, sizeof(char));
	
	i = 0;
	while (fgets(str, sizeof(str), fp1) != 0){
		arr[i] = str[0];
		i++;
	}
	
	permutation(arr, count, 0, fp2);
	
	fputs("\n--@*'-'*@--------\n", fp2);
	fputs("YouKyeong Kang\n", fp2);
	fputs("20172051, CAU\n", fp2);
	fputs("--------@*'-'*@--\n", fp2);
	
	fclose(fp2);
	
	fp2 = fopen(argv[2], "r");
	
	while(fgets(str, sizeof(str), fp2) != NULL){
		printf("%s", str);
	}
	
	free(arr);
	
	fclose(fp1);
	fclose(fp2);
	
	return 0;

}
	
	
	