#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h> 
#include <math.h> 
#include <string.h> 
#include <stdlib.h>
int b = 1;
void swap(char *x, char *y)
{
	char temp;
	temp = *x;
	*x = *y;
	*y = temp;
}
void permute(char a[], int l, int r, FILE *fp2)
{
	int i;
	if (l == r) {
		
		fprintf(fp2, "[%03d]", b);
		fprintf(fp2, "%s\n", a);
		b++;
	}
	else
	{
		for (i = l; i <= r; i++)
		{
			swap((a + l), (a + i));
			permute(a, l + 1, r, fp2);
			swap((a + l), (a + i)); 
		}
	}
}

int main(int argc, char* argv[]) {

	FILE *fp1, *fp2;
	if ((fp1 = fopen(argv[1], "rt")) == NULL) { 
		printf("fail to open file.");
		return 0;
	}
	if ((fp2 = fopen(argv[2], "wt")) == NULL) { 
		printf("fail to create file for write.");
		return 0;
	}

	char str[6];//�迭�� ũ��� input.txt�� �迭�� ���� output.txt�� ���� �ٲ��.
	fscanf(fp1, "%s", str); 
	int n = strlen(str);
	permute(str, 0, n - 1, fp2);


	fprintf(fp2,"\nHyeonHo Cha\nStudent ID : 20183968\n");
	
	fclose(fp1);
	fclose(fp2);
	return 0;
}