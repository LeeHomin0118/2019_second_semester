#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h> 
#include <string.h>

void swap(char* a, char* b)
{
    char temp = *a;
    *a = *b;
    *b = temp;
}

void permutation(char* pSets, int nIndex, int len, FILE *file)
{
    int i;
    static int count = 0;
    
    if (nIndex == len)
    {
        count++;
        fprintf(file, "[%03d] ", count);
        for (int j = 0; j < len; j++)
        {
            fprintf(file, "%c ", pSets[j]);
        }
        fprintf(file, "\n");
    }
    else
    {
        for (i = nIndex; i < len; i++)
        {
            swap((pSets + nIndex), (pSets + i));
            permutation(pSets, nIndex + 1, len, file);
            swap((pSets + nIndex), (pSets + i));
        }
    }
}

int main(int argc, char* argv[])
{
    FILE *fp1, *fp2;
    int nNumber;

    if((fp1=fopen(argv[1],"r")) == NULL)
    {
        printf("fail to open file.\n");
        exit(1);
    }
    if((fp2=fopen(argv[2],"wt")) == NULL)
    {
        printf("fail to create file for write.\n");
        exit(1);
    }

    fscanf(fp1, "%d", &nNumber);

    if (nNumber > 6) 
    {
        printf("Error! The maximum number is 6.\n");
        exit(1);
    }

    char* pSets = (char*) calloc(nNumber, sizeof(char));

    for(int i = 0; i < nNumber; i++)
    {   
        fscanf(fp1, "%s", &pSets[i]);
    }
    
    permutation(pSets, 0, nNumber, fp2);

    //signature
    fprintf(fp2, " _______________________________\n|                               |\n|                               |\n| '-') { 20170457 Isabella )    |\n -------------------------------\n");

    free(pSets);

    fclose(fp1);
    fclose(fp2);

    return 0;
}