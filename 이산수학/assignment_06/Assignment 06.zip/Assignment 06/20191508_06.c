#if _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif
#include <stdio.h>
#define FALSE 0
#define TRUE 1

int serial = 1;
typedef char bool;
void writePermutations(FILE* inputF, char* chars, char* result, bool* usedChars, int step, int cardinality);
int main(int argc, char* argv[]) {
	if (argc < 3) {
		printf("Not enough arguments provided");
		return 1;
	}

	FILE *inputF = fopen(argv[1], "r"),
		*outputF = fopen(argv[2], "w");
	if (inputF == NULL) {
		printf("Error while opening input file");
		return 2;
	}
	else if (outputF == NULL) {
		printf("Error while opening output file");
		return 3;
	}

	int charCnt;
	fscanf(inputF, "%d", &charCnt);
	char *chars = (char*)malloc(sizeof(char) * charCnt),
	     *result = (char*)malloc(sizeof(char) * charCnt);
	for (int i = 0; i < charCnt; i++) {
		char tmp;
		fscanf(inputF, "%c", &tmp);
		if (tmp == ' ' || tmp == '\n' || tmp == '\r') {
			i--;
			continue;
		}
		chars[i] = tmp;
	}

	bool* usedChars = (bool*)malloc(sizeof(bool) * charCnt);
	for (int i = 0; i < charCnt; i++)
		usedChars[i] = FALSE;

	writePermutations(outputF, chars, result, usedChars, 0, charCnt);

	fprintf(outputF, "\n");
	fprintf(outputF, "=====================\n");
	fprintf(outputF, " .----..-.  .-.  .-.\n");
	fprintf(outputF, "{ {__   \ \/ /.-.| |\n");
	fprintf(outputF, ".-._} }  }  { | {} |\n");
	fprintf(outputF, "`----'   `--' `----'\n");
	fprintf(outputF, "\n");
	fprintf(outputF, "Yeonjin Shin\n");
	fprintf(outputF, "Student ID : 20191508\n");
	fprintf(outputF, "=====================\n");
}
void writePermutations(FILE* outputF, char* chars, char* result, bool* usedChars, int step, int cardinality) {
	if (step == cardinality) {
		fprintf(outputF, "[%03d] ", serial++);
		for (int i = 0; i < cardinality; i++) {
			fprintf(outputF, "%c ", result[i]);
		}
		fprintf(outputF, "\n");
	}
	else {
		for (int i = 0; i < cardinality; i++) {
			if (usedChars[i])
				continue;
			usedChars[i] = TRUE;
			result[step] = chars[i];
			writePermutations(outputF, chars, result, usedChars, step + 1, cardinality);
			usedChars[i] = FALSE;
		}
	}
}