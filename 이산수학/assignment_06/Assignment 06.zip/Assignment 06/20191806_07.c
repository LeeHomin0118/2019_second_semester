//
//  main.c
//  ASS07
//
//  Created by 王志鹏 on 2019/11/21.
//  Copyright © 2019 wangzhipeng. All rights reserved.
//

#include <stdio.h>
#include<stdlib.h>
int i,d;
void Swap(int *lhs, int *rhs)
{
    int t = *lhs;
 
    *lhs = *rhs;
    *rhs = t;
}
 
void FullPermutation(int source[], int begin, int end)
{
    FILE*fp2;
    FILE*fp1; fp1=fopen("/User/wangzhipeng/20191806_07 input.txt","r");
    fp2=fopen("/User/wangzhipeng/20191807_07 output.txt","w");
    if(fp2==NULL){
        printf("fale to write file.");
    }else{    fprintf(fp2,"****************\n");
            fprintf(fp2,"******wang******\n");
            fprintf(fp2,"**zhi*****peng**\n");
            fprintf(fp2,"****************\n");
            fprintf(fp2,"*****20191806***\n");
            fprintf(fp2,"****************\n");
    if (begin >= end)
    {
        for (i = 0; i < end; i++)
        {
            fprintf(fp2,"%d", source[i]);
        }
        fprintf(fp2,"\n");
    }
    else
    {
        for (i = begin; i < end; i++)
        {
            if (begin != i)
            {
                Swap(&source[begin], &source[i]);
            }
 
           
            FullPermutation(source, begin + 1, end);
 
            if (begin != i)
            {
                Swap(&source[begin], &source[i]);
            }
        }
    }
    }fclose(fp2);
}
int main(){
    FILE*fp1;
    fp1=fopen("/Users/wangzhipeng/20191806-07 intput.txt","w");
    if(fp1==NULL){
        printf("fale to open file.");
    }
    else{
        scanf("%i",&d);
        for(i=0;i<d;i++)
        
            fprintf(fp1,"%c\n",i+'a');
            fclose(fp1);
        
      
    }

 


    int source[30];
    int i, count;
 
    scanf("%d", &count);
 
  
    for (i = 0; i < count; i++)
    {
        source[i] = i + 1;
    }
 
    FullPermutation(source, 0, count);
 
    return 0;
}

