#include <stdio.h>
#include <stdlib.h>

#define SWAP(a, b) { int t = a; a = b; b = t; }

FILE *f_in, *f_out;
int m, count = 1;

void P(char* arr, int n);
void signature();

int main(int argc, char** argv)
{
    char *arr;

    f_in = fopen(argv[1], "r");
    f_out = fopen(argv[2], "w");

    fscanf(f_in, "%d\n", &m);

    arr = calloc(m, sizeof(char));

    for (int i = 0; i < m; i++) {
        fscanf(f_in, "%c\n", &arr[i]);
    }

    P(arr, 0);

    signature();

    free(arr);

    fclose(f_in);
    fclose(f_out);
}

void P(char* arr, int n)
{
    if (n == m - 1) {
        fprintf(f_out, "[%03d] ", count++);
	for (int i = 0; i < m; i++) {
            fprintf(f_out, "%c ", arr[i]);
	}
	fprintf(f_out, "\n");
    } else {
	for (int i = n; i < m; i++) {
            SWAP(arr[n], arr[i]);
	    P(arr, n + 1);
	    SWAP(arr[n], arr[i]);
	}
    }
}

void signature()
{
    fprintf(f_out, "\n");
    fprintf(f_out, "********************************\n");
    fprintf(f_out, "*                              *\n");
    fprintf(f_out, "* Name       : Park Younghyeon *\n");
    fprintf(f_out, "* Student ID : 20191404        *\n");
    fprintf(f_out, "*                              *\n");
    fprintf(f_out, "*      00000        00000      *\n");
    fprintf(f_out, "*     0     0      0     0     *\n");
    fprintf(f_out, "*    0     0 0    0     0 0    *\n");
    fprintf(f_out, "*    0    0  0    0    0  0    *\n");
    fprintf(f_out, "*    0   0   0    0   0   0    *\n");
    fprintf(f_out, "*    0  0    0    0  0    0    *\n");
    fprintf(f_out, "*    0 0     0    0 0     0    *\n");
    fprintf(f_out, "*     0     0      0     0     *\n");
    fprintf(f_out, "*      00000        00000      *\n");
    fprintf(f_out, "*                              *\n");
    fprintf(f_out, "********************************\n");   
}
