#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

void swap(char* x, char* y)
{
	char temp;

	temp = *x;
	*x = *y;
	*y = temp;
}

int count = 1;

void permutation(int num, int n, char* arr, FILE *outputFile)
{
	if (num == 1) {
		fprintf(outputFile, "[%03d]", count++);
		for (int i = 0; i < n; i++)
			fprintf(outputFile, " %c", arr[i]);
		fprintf(outputFile, "\n");
		return;
	}

	else {
		for (int i = 0; i < num; i++) {
			swap(&arr[i], &arr[num - 1]);
			permutation(num - 1, n, arr, outputFile);
			swap(&arr[i], &arr[num - 1]);
		}
	}
}

int main(int *argc, char *argv[])
{
	FILE *inputFile, *outputFile;

	if ((inputFile = fopen(argv[1], "r")) == NULL) {
		printf("Fail to open file.");
		return 0;
	}

	if ((outputFile = fopen(argv[2], "w")) == NULL) {
		printf("Fail to create file for write.");
		return 0;
	}

	int num;
	char * arr;

	fscanf(inputFile, "%d", &num);

	arr = (char*)malloc(num * sizeof(char));

	for (int i = 0;i < num ;i++) 
		fscanf(inputFile, " %c", &arr[i]);

	permutation(num, num, arr, outputFile);

	free(arr);

	fprintf(outputFile, "|---*-*-*-*-*-*-*-*-*---|\n");
	fprintf(outputFile, "|                          |\n");
	fprintf(outputFile, "| 20190564   EomChanwoo |\n");
	fprintf(outputFile, "|                          |\n");
	fprintf(outputFile, "|---*-*-*-*-*-*-*-*-*---|");

	fclose(inputFile);
	fclose(outputFile);

	return 0;
}