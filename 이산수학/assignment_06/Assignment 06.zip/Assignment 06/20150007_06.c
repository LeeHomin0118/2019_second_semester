#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int count = 1;

void swap(char *x, char *y)
{
	char temp;
	temp = *x;
	*x = *y;
	*y = temp;
}

void permutation(int start,int end, char* input, FILE *fp)
{
	// basis step
	if (end==start)
	{
		//fprintf(fp, "[%.3d] %d\n", nNumber + nIndex, pNumbers[0]);
		int number = strlen(input);
		fprintf(fp,"[%.3d] ", count++);
		for (int i = 0;i < number; i++) {
			fprintf(fp,"%c ",input[i]);
		}
		fprintf(fp,"\n");
	}
	// recursive step
	else
	{
		for (int i = start; i <= end; i++) {
			swap((input + start), (input + i));
			permutation(start+1, end,input,fp);
			swap((input + start), (input + i));
			
		}
		
	}
}


int main(int argc, char* argv[]) {

	FILE *fp1, *fp2;
	char str[5];   // change the number appropriately to your program
	// read_file = argv[1]
	// write_file = argv[2]
	// see the usage of r, rt, w, wt, r+, w+
	if ((fp1 = fopen(argv[1], "r")) == NULL) { //fail to open file for read
		printf("fale to open file.");
		return 0;
	}
	if ((fp2 = fopen(argv[2], "wt")) == NULL) { //fail to open file for write
		printf("fail to create file for write.");
		return 0;
	}
	int nNumber = 0;
	fgets(str, sizeof(str), fp1);
	nNumber = atoi(str);   // read from the input file
	char*    inputChars = (char*)calloc(nNumber+1, sizeof(char));
	int i = 0;
	while (fgets(str, sizeof(str), fp1)) {   // read a file and write to another file line by line
		inputChars[i] = str[0];
		i++;
	}
	inputChars[i] = '\0';

	permutation(0,nNumber-1,inputChars, fp2);

	free(inputChars);
	fputs("---------CopyRight AhnSeungJae----------------\n", fp2);
	fputs("Student ID: 20150007\n", fp2);
	fputs("Ahn SeungJae\n", fp2);
	fputs("---------don't copy my Code-----------------\n", fp2);
	//

	fclose(fp1);
	fclose(fp2);
	return 0;
}