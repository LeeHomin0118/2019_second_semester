#include <stdio.h>

void fPrintPermutation(char*, int , int, FILE*); //arr, depth(default = 0), sizeof(arr) / sizeof(char), output.txt
void Swap(char* arr, int i, int j); //arr[i]와 arr[j]를 교환

int main(int argc, char* argv[])
{
	FILE *fpi = fopen(argv[1], "rt"); //input.txt
	FILE *fpo = fopen(argv[2], "wt"); //output.txt
	
	int num;
	fscanf(fpi, "%d", &num);
	
	char arr[num];
	
	for (int i = 0; i < num; i++)
	{
		fgetc(fpi);
		arr[i] = fgetc(fpi);
	}

	fPrintPermutation(arr, 0, num, fpo);
		
	/*           signiture           */
	fputs("▨▤▤▤▤▤▤▤▤▧\n", fpo);
	fputs("▥                       ▥\n", fpo);
	fputs("▥  20196261 임결  ▥\n", fpo);
	fputs("▥                       ▥\n", fpo);	
	fputs("▧▤▤▤▤▤▤▤▤▨\n", fpo); 
	/*           signiture           */
	
	fclose(fpi);
	fclose(fpo);
	
	return 0;	
}

void fPrintPermutation(char *arr, int depth, int size, FILE *fpo)
{
	static int count = 1;

	if (depth == size)
	{
		fprintf(fpo, "[%03d] ", count);
		for (int i = 0; i < size; i++)
			fprintf(fpo, "%c ", arr[i]);
		fputs("\n", fpo);
		
		count++;
		return;
	}

	for (int i = depth; i < size; i++)
	{
		Swap(arr, i, depth);
		fPrintPermutation(arr, depth +  1, size, fpo);
		Swap(arr, i, depth);
	}
}

void Swap(char *arr, int i, int j)
{
	int temp = arr[i];
	arr[i] = arr[j];
	arr[j] = temp;	
}
