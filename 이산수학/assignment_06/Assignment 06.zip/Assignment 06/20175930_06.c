#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>

char data[10];
int cnt=1;
int swap(int i, int j)
{
	char temp;
	if (i == j) return 0;
	temp = data[i];
	data[i] = data[j];
	data[j] = temp;
	return 0;

}

int permutation(int totalN,int n, FILE * fp2)
{
	int i;

	if(n == 1)
	{
		fprintf(fp2,"[%03d] ", cnt);
		for(i = 0; i < totalN; i++) {
			fprintf(fp2, "%c ", data[i]);
		}
		fprintf(fp2,"\n");
		cnt++;
		return 0;
	}

	for(int i = 0; i < n; i++)
	{
		swap(i, n-1);
		permutation(totalN, n-1, fp2);
		swap(i, n-1);
	}
}

int main(int argc, char * argv[])
{
	FILE * fp1, * fp2;
	int n;
	int k =0;
	char i;
	char text[5];
	fp1 = fopen(argv[1], "r");
	
	while (fscanf(fp1, "%c", &i) != EOF)
	{
		

		if (k >=1) {	
			text[k-1] = i;
			k++;
		}
		else if (k ==0)
		{
			k++;
		}	
	}

	for(int i = 0; i <3; i++)
	{
		data[i] = text[(2*i)+1];
	}
	fclose(fp1);
	fp2 = fopen(argv[2], "w");
	n = sizeof(data)/ sizeof(int) + 1;
	permutation(n, n, fp2);
	fprintf(fp2,"******************* \n");
	fprintf(fp2,"김동규 \nStudent ID: 20175930\n");
	fprintf(fp2,"       *         \n");
	fprintf(fp2,"     * 28 *         \n");
	fprintf(fp2,"       *         \n");	
	fprintf(fp2,"$$$$$$$$$$$$$$$$$$$$ \n");
	fclose(fp2);
	return 0;
}
	
