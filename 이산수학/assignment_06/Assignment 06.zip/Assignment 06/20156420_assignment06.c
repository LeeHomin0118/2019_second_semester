//
//  main.c
//  assignment1
//
//  Created by Alex Park on 27/09/2019.
//  Copyright © 2019 Alex Park. All rights reserved.
//
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
char *data[20];

void swap(char* x, char* y)
{
    char temp;
    temp = *x;
    *x = *y;
    *y = temp;
}


void permute(char a[], int l, int r, int j, FILE *fp2)
{
    int i;
    
    if (l == r){
        
        fprintf(fp2,"[%04d]%c%c%c\n",j, a[0],a[1],a[2]);
        
    }
    
    else {
        for (i = l; i <= r; i++) {
            
            swap(&a[l], &a[i]);
            permute(a, l+1, r,j, fp2);
            swap(&a[l], &a[i]);
            j +=1;
        }
    }
}
int main(int argc, char *argv[])
{
    FILE *fp1,*fp2;
    if((fp1=fopen(argv[1],"r"))  == NULL){ //fail to open file for read
        printf("fail to open file.");
        return 0;
    }
    if((fp2=fopen(argv[2],"wt")) == NULL){ //fail to open file for write
        printf("fail to create file for write.");
        return 0;
    }
    
    char str[64];
    char temp[64];
    int i = 0;
    
    while(fgets(str,sizeof(str),fp1)){   // read a file and write to another file line by line
        
        printf("%s",str);
        strcpy(&temp[i], str);
        
        i++;
        // fputs(str, fp2);
    }
    
    int n = atoi(&temp[0]);
   
    printf("%d\n",n);
    printf("%c\n",temp[0]);
    printf("%c\n",temp[1]);
    printf("%c\n",temp[2]);
    
    int j=1;
    char st[64];
    for (int t = 1; t<n+1;t++){
        st[t-1]=temp[t];
    }
    permute(st, 0, n - 1,j,fp2);
    
    
    
    
    fprintf(fp2,"Created by Alex Park on 7/11/2019.\n");
    fprintf(fp2,"Copyright © 2019 Alex Park. All rights reserved.\n");
    fclose(fp1);
    fclose(fp2);
    return 0;

    
   
    
}
