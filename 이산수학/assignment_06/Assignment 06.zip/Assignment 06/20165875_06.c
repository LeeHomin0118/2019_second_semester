#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LOG_BUFFER_SIZE 32768


int g_lineCounter = 0;
char g_logBuffer[LOG_BUFFER_SIZE] = { 0, };

void Log( char* message )
{
    sprintf( g_logBuffer + strlen( g_logBuffer ), "%s", message );
}

void PrintSigniture()
{
    Log( "************************\n" );
    Log( "Eun-Kyu Lim\n" );
    Log( "Stundent ID : 20165875\n" );
    Log( "************************\n" );
}

void ProcessOutput( const char* filePath )
{
    
    printf( "%s", g_logBuffer );
    
    
    FILE* fileToWrite = fopen( filePath, "wt" );
    if( NULL == fileToWrite )
    {
        printf( "fail - %s", filePath );
        return;
    }

    fputs( g_logBuffer, fileToWrite );
    fclose( fileToWrite );
}

void Swap( char* x, char* y )
{
    char temp;
    temp = *x;
    *x = *y;
    *y = temp;
}

void Permute( char* string, int startIndex, int endIndex )
{
   int i;
   if ( startIndex == endIndex )
   {
       char buffer[64];
       sprintf( buffer, "[%03d] %s\n", ++g_lineCounter, string );
       Log( buffer );
   }
   else
   {
       for( i = startIndex; i <= endIndex; i++ )
       {
          Swap( string + startIndex, string + i );
          Permute( string, startIndex + 1, endIndex );        
       }
   }
}

int main( int argc, char * argv[] )
{
    char* filePathToRead = argv[1];
    char* filePathToWrite = argv[2];
    
    FILE *fp;
    if( ( fp = fopen( filePathToRead, "r" ) ) == NULL )
    {
        printf( "fail to open file.\n" );
        return 0;
    }
    
    
    char readBuffer[64];
    fgets( readBuffer, sizeof( readBuffer ), fp );
    int characterCount = atoi( readBuffer );
    
    if( characterCount > 6 )
    {
       
        Log( "Error: Too many numbers \n" );
    }
    else
    {
      
        char string[ characterCount + 1 ];
        
      
        for( int i = 0; i < characterCount; i++ )
        {
            fgets( readBuffer, sizeof( readBuffer ), fp );
            string[i] = *readBuffer;
        }
        fclose( fp );
        string[ characterCount ] = '\0';
        
        Permute( string, 0, characterCount - 1 );
    }
    

    PrintSigniture();
    

    ProcessOutput( filePathToWrite );
    
    return 0;
}
