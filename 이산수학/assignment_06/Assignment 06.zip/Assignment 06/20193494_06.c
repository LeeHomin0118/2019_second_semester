#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_STR 6

int perm(int *ary, int depth, int n, int **table);
void print(char **list, FILE *fp2, int **table, int n, int fact);
void swap(int *ary, int i, int j);


int main(int argc, char* argv[]) {
	FILE *fp1, *fp2;
	if ((fp1 = fopen(argv[1], "r")) == NULL) { //fail to open file for read
		printf("fale to open file.");
		return 0;
	}
	if ((fp2 = fopen(argv[2], "wt")) == NULL) { //fail to open file for write
		printf("fail to create file for write.");
		return 0;
	}

	int nNumber, fact=1;
	char str[MAX_STR];

	fgets(str, MAX_STR, fp1);
	str[strlen(str)-1] = '\0';
	nNumber = atoi(str);

	char **list = (char **)malloc(nNumber * sizeof(char *));
	for (int i = 0; i < nNumber; i++) {
		list[i] = (char *)malloc(MAX_STR * sizeof(char));
	}

	for (int i = 1; i < nNumber+1; i++) {
		fact = fact * i;
	}


	for (int i = 0; i < nNumber; i++) {
		fgets(str, MAX_STR, fp1);
		if(str[strlen(str) - 1] == '\n')
			str[strlen(str)-1] = '\0';
		strcpy(list[i], str);
	}

	int *stack = malloc(sizeof(int)*nNumber);
	

	for (int i = 0; i < nNumber; i++) stack[i] = i;
	int **table = (int **)malloc(fact * sizeof(int*));
	for (int i = 0; i < fact; i++) {
		table[i] = (int *)malloc(nNumber * sizeof(int));
	}

	
	for (int i = 0; i < fact; i++) {
		for (int j = 0; j < nNumber; j++) {
			table[i][j] = -1;
		}
	}

	
	perm(stack, 0, nNumber, table);
	print(list, fp2, table, nNumber, fact);

	fprintf(fp2, "\n*************************\n*  I'm Seo Hyeong Moon! *\n*        Hi Hello       *\n*************************");


	return 0;
	
}

void print(char **list, FILE *fp2, int **table, int n, int fact) {
	for (int i = 0; i < fact; i++) {
		fprintf(fp2, "[%03d] ", i+1);
		for (int j = 0; j < n; j++) {
			fprintf(fp2, "%s ", list[table[i][j]]);
		}
		fprintf(fp2, "\n");
	}
}

int perm(int *ary, int depth, int n, int **table) {
	
	if (depth == n) {
		int k = 0, count = 0;
		while (count < 1) {
			if (table[k][0] < 0) {
				for (int j = 0; j < n; j++) {
					table[k][j] = ary[j];
				}
				count++;
			}
			k++;
		}
		return 0;
	}

	for (int i = depth; i < n; i++) {
		swap(ary, i, depth);
		perm(ary, depth + 1, n,  table);
		swap(ary, i, depth);
	}
	
	return 0;
}

void swap(int *ary, int i, int j) { 
	int temp = ary[i]; 
	ary[i] = ary[j]; 
	ary[j] = temp; 
}


