//
//  main.c
//  white
//
//  Created by 王志鹏 on 17/10/2019.
//  Copyright © 2019 wangzhipeng. All rights reserved.
//

#include<stdio.h>
#include<stdlib.h>
void main()
{  FILE *fp1,*fp2;
   fp1=fopen("/desktop/huuuu/ASSIGNMENT.txt","r");
  fp2=fopen("/desktop/assignment/AS.txt","w");
  printf("%d %d",*fp1,*fp2);
  char a[20];
  fread(a,sizeof(char),10,fp1);
  fwrite(a,sizeof(char),10,fp2);
  fclose(fp1);
  fclose(fp2);
}
