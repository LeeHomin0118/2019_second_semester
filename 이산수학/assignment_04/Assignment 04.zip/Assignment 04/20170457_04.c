//
//  20170457_04.c
//  assignment04
//
//  Created by Isabella on 12/10/2019.
//  Copyright © 2019 Isabella. All rights reserved.
//
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <math.h> //for using pow()
#include <wchar.h> //extended ASCII code
#include <locale.h>
#include <stdlib.h>

void printPowerSet(char *set, int setSize) {
    FILE *writefile = fopen("20170457_04.txt", "w");

    int powSetSize = pow(2, (setSize - 1));
    int count = 1;
    int empty = 248;    //공집합 Unicode 코드
    
    setlocale(LC_ALL, "");

    for (int i = 0; i < powSetSize; i++) {
        if (count == 1) {       //공집합 출력
            fwprintf(writefile, L"[%04d] %lc\n", count, (wchar_t)empty);
            count++;
            continue;
        }
        fprintf(writefile, "[%04d] ", count);
        count++;

        for (int j = 0, comma = 0; j <= setSize; j++) {
            if (i & (1<<j)) {
                if (comma > 0) {
                    fprintf(writefile, ", %c", set[j]);
                }
                else {
                    fprintf(writefile, "%c", set[j]);
                    comma++;
                }
            }         
        }
        fprintf(writefile, "\n");
    }

    fclose(writefile);
}

int main(int argc, const char* argv[]) {
    char set[10];
    
    //원소 개수가 10개 이상일 경우 오류
    if (argc > 11) {
        printf("Error! The maximum number is 10.\n");
        exit(1);
    }
    else if (argc == 1) {       //원소를 입력하지 않은 경우 오류
        printf("Enter the set.\n");
        exit(1);
    }

    //문자열 배열에 집합 저장
    for (int i = 0; i < (argc - 1) ; i++) {
        set[i] = *argv[i + 1];
    }
    
    printPowerSet(set, argc);
    
    //signature
    printf(" _______________________________\n|                               |\n|                               |\n| '-') { 20170457 Isabella )    |\n -------------------------------\n");
    
    return 0;
}
