#include <stdio.h>
#include <math.h>
#include <wchar.h>
#include <locale.h>

#define bitcheck(n, digit) (n>>(digit)) % 2


int main(int argc, char *argv[]) {
	FILE *f;
	setlocale(LC_CTYPE, "");
	wchar_t empty = 0x00D8;
	int oncnt;
	if (argc > 11) {
		printf("Too many operator.");
		return 0;
	}

	if ((f = fopen(argv[1], "wt")) == NULL) { //fail to open file for write
		printf("fail to create file for write.");
		return 0;
	}

	else {
		for (int num = 0; num < pow(2, argc - 2); num++) {
			oncnt = 0;
			fprintf(f,"[%04d] : ", num);
			if (num == 0){
				fwprintf(f,L"%lc", empty);
			}

			else {
				for (int i = 0; i < (argc - 1); i++) {
					if (bitcheck(num, i) != 0) {
						if (oncnt > 0)
							fprintf(f,", ");
						fprintf(f,"%s", argv[i + 2]);
						oncnt++;
					}
				}
			}
			fprintf(f,"\n");
		}
	}





	fprintf(f,"\n*************************\n*  I'm Seo Hyeong Moon! *\n*        Hi Hello       *\n*************************");
}