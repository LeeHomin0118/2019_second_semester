#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(int argc, char* argv[])
{
	FILE* p1 = fopen(argv[1], "w");

	int count = 1;
	int i, j, k, l, m, n, o, p, q, r;
	int sn = argc;		//�κ������� ������ ���� + 1

	fprintf(p1, "[%04d] %c\n", count, 155);
	printf("[%04d] %c\n", count++, 155);

	for (i = 2; i < sn; i++)
	{
		fprintf(p1, "[%04d] %c\n", count, *argv[i]);
		printf("[%04d] %c\n", count++, *argv[i]);	// ���� ���� 1��
	}
	sn--; // 4

	for (i = 2; i < sn; i++)		// ���� ���� 2�� i = 1 2 3 
	{
		for (j = i + 1; j < sn + 1; j++)		//j = 2
		{
			fprintf(p1, "[%04d] %c, %c\n", count, *argv[i], *argv[j]);
			printf("[%04d] %c, %c\n", count++, *argv[i], *argv[j]);
		}
	}
	sn--;	// 3

	for (i = 2; i < sn; i++)
	{
		for (j = i + 1; j < sn + 1; j++)
		{
			for (k = j + 1; k < sn + 2; k++)
			{
				fprintf(p1, "[%04d] %c, %c, %c\n", count, *argv[i], *argv[j], *argv[k]);
				printf("[%04d] %c, %c, %c\n", count++, *argv[i], *argv[j], *argv[k]);
			}
		}
	}
	sn--;

	for (i = 2; i < sn; i++)
	{
		for (j = i + 1; j < sn + 1; j++)
		{
			for (k = j + 1; k < sn + 2; k++)
			{
				for (l = k + 1; l < sn + 3; l++)
				{
					fprintf(p1, "[%04d] %c, %c, %c, %c\n", count, *argv[i], *argv[j], *argv[k], *argv[l]);
					printf("[%04d] %c, %c, %c, %c\n", count++, *argv[i], *argv[j], *argv[k], *argv[l]);
				}
			}

		}
	}
	sn--;

	for (i = 2; i < sn; i++)
	{
		for (j = i + 1; j < sn + 1; j++)
		{
			for (k = j + 1; k < sn + 2; k++)
			{
				for (l = k + 1; l < sn + 3; l++)
				{
					for (m = l + 1; m < sn + 4; m++)
					{
						fprintf(p1, "[%04d] %c, %c, %c, %c, %c\n", count, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m]);
						printf("[%04d] %c, %c, %c, %c, %c\n", count++, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m]);

					}
				}
			}

		}
	}
	sn--;

	for (i = 2; i < sn; i++)
	{
		for (j = i + 1; j < sn + 1; j++)
		{
			for (k = j + 1; k < sn + 2; k++)
			{
				for (l = k + 1; l < sn + 3; l++)
				{
					for (m = l + 1; m < sn + 4; m++)
					{
						for (n = m + 1; n < sn + 5; n++)
						{
							fprintf(p1, "[%04d] %c, %c, %c, %c, %c, %c\n", count, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m], *argv[n]);
							printf("[%04d] %c, %c, %c, %c, %c, %c\n", count++, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m], *argv[n]);
						}
					}

				}
			}

		}
	}
	sn--;

	for (i = 2; i < sn; i++)
	{
		for (j = i + 1; j < sn + 1; j++)
		{
			for (k = j + 1; k < sn + 2; k++)
			{
				for (l = k + 1; l < sn + 3; l++)
				{
					for (m = l + 1; m < sn + 4; m++)
					{
						for (n = m + 1; n < sn + 5; n++)
						{
							for (o = n + 1; o < sn + 6; o++)
							{
								fprintf(p1, "[%04d] %c, %c, %c, %c, %c, %c, %c\n", count, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m], *argv[n], *argv[o]);
								printf("[%04d] %c, %c, %c, %c, %c, %c, %c\n", count++, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m], *argv[n], *argv[o]);
							}
						}
					}

				}
			}

		}
	}
	sn--;

	for (i = 2; i < sn; i++)
	{
		for (j = i + 1; j < sn + 1; j++)
		{
			for (k = j + 1; k < sn + 2; k++)
			{
				for (l = k + 1; l < sn + 3; l++)
				{
					for (m = l + 1; m < sn + 4; m++)
					{
						for (n = m + 1; n < sn + 5; n++)
						{
							for (o = n + 1; o < sn + 6; o++)
							{
								for (p = o + 1; p < sn + 7; p++)
								{
									fprintf(p1, "[%04d] %c, %c, %c, %c, %c, %c, %c, %c\n", count, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m], *argv[n], *argv[o], *argv[p]);
									printf("[%04d] %c, %c, %c, %c, %c, %c, %c, %c\n", count++, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m], *argv[n], *argv[o], *argv[p]);
								}
							}
						}
					}

				}
			}

		}
	}
	sn--;

	for (i = 2; i < sn; i++)
	{
		for (j = i + 1; j < sn + 1; j++)
		{
			for (k = j + 1; k < sn + 2; k++)
			{
				for (l = k + 1; l < sn + 3; l++)
				{
					for (m = l + 1; m < sn + 4; m++)
					{
						for (n = m + 1; n < sn + 5; n++)
						{
							for (o = n + 1; o < sn + 6; o++)
							{
								for (p = o + 1; p < sn + 7; p++)
								{
									for (q = p + 1; q < sn + 8; q++)
									{
										fprintf(p1, "[%04d] %c, %c, %c, %c, %c, %c, %c, %c, %c\n", count, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m], *argv[n], *argv[o], *argv[p], *argv[q]);
										printf("[%04d] %c, %c, %c, %c, %c, %c, %c, %c, %c\n", count++, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m], *argv[n], *argv[o], *argv[p], *argv[q]);
									}
								}

							}
						}
					}

				}
			}

		}
	}
	sn--;

	for (i = 2; i < sn; i++)
	{
		for (j = i + 1; j < sn + 1; j++)
		{
			for (k = j + 1; k < sn + 2; k++)
			{
				for (l = k + 1; l < sn + 3; l++)
				{
					for (m = l + 1; m < sn + 4; m++)
					{
						for (n = m + 1; n < sn + 5; n++)
						{
							for (o = n + 1; o < sn + 6; o++)
							{
								for (p = o + 1; p < sn + 7; p++)
								{
									for (q = p + 1; q < sn + 8; q++)
									{
										for (r = q + 1; r < sn + 9; r++)
										{
											fprintf(p1, "[%04d] %c, %c, %c, %c, %c, %c, %c, %c, %c, %c\n", count, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m], *argv[n], *argv[o], *argv[p], *argv[q], *argv[r]);
											printf("[%04d] %c, %c, %c, %c, %c, %c, %c, %c, %c, %c\n", count++, *argv[i], *argv[j], *argv[k], *argv[l], *argv[m], *argv[n], *argv[o], *argv[p], *argv[q], *argv[r]);
										}
									}

								}

							}
						}
					}

				}
			}

		}
	}
	sn--;

	fclose(p1);

	printf("\n�� �й��� 20190791�̰�\n�� �̸��� ���ȯ�Դϴ�");
}