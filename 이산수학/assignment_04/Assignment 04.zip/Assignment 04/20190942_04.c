#define _CRT_SECURE_NO_WARNINGS
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int num_case;
int cardi;
int digit_s, digit;
int comma_trig = 0;

int main(int argc, char *argv[])
{
    FILE *fp;
    fp = fopen(argv[1], "w");

	if(argc >= 13) //���α׷� �̸�, txt�� ���� 12���� argc�� �ִ�
	{
		printf("exceeded number(max: 10)");
		return -1;
	}

	cardi = pow(2, argc-2); //������ ����

	fprintf(fp,"[0001] ��\n");

	for(num_case = 1; num_case <= cardi-1; num_case++)
	{
		digit = num_case;

		fprintf(fp,"[%04d] ", num_case + 1);
		for(digit_s = 1; digit_s <= argc-2; digit_s++)
		{

			 if(digit % 2 == 1)
			 {
				if(comma_trig != 0) fprintf(fp,", ");
				fprintf(fp,"%c", argv[digit_s+1][0]);
				comma_trig++;
			 }
			 digit >>= 1;
		}

		comma_trig = 0;

		fprintf(fp,"\n");
	}

	//print signiture

	printf("\n\n\n");
	printf("     ( ||| )\n");
	printf("   ( ||||| )\n");
	printf("   ( �ڶ󳪴� )\n");
	printf("   (( 20190942 ))\n");
	printf("   ((( �ڰ��� )))\n");
	printf("   (( ���� ))\n");
	printf("    ( ||||| )\n");
	for (int i = 0; i < 8; i++)
	{
		printf("	|||||\n");
	}
	printf("\n20190942 Park Gwan Bin\n");

	fprintf(fp,"\n\n\n");
	fprintf(fp,"     ( ||| )\n");
	fprintf(fp,"   ( ||||| )\n");
	fprintf(fp,"   ( �ڶ󳪴� )\n");
	fprintf(fp,"   (( 20190942 ))\n");
	fprintf(fp,"   ((( �ڰ��� )))\n");
	fprintf(fp,"   (( ���� ))\n");
	fprintf(fp,"    ( ||||| )\n");
	for (int i = 0; i < 8; i++)
	{
		fprintf(fp,"      |||||\n");
	}
	fprintf(fp,"\n20190942 Park Gwan Bin\n");

    fclose(fp);
	return 0;
}
