#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <locale.h>
char *data[20];
char *selected[10];
int end;
int cnt = 0;


int powerset(int depth, int start, FILE * fp)
{
	int i;
	
	if (cnt < 10) fprintf(fp, "[000%d]", cnt);
	else if (cnt >= 10 && cnt <100) fprintf(fp, "[00%0d]", cnt);
	else if (cnt >= 100 && cnt <1000) fprintf(fp, "[0%d]", cnt);
	else if (cnt >= 1000 && cnt <10000) fprintf(fp, "[%d]", cnt);
	if (cnt == 0) 
	{
		setlocale(LC_ALL, "");
		fprintf(fp," %lc", (wchar_t) 248);
	}	
	
	for (i = 0; i < depth; i++)
	{
		if (i != 0) fprintf(fp, ",");
		fprintf(fp, " %s", selected[i]);
	}
	fprintf(fp, "\n");
	cnt++;
	for (i = start; i < end; i++)
	{	
		selected[depth] = (data[i]); 
		powerset(depth+1, i+1, fp);
	}

	return 0;
}

int main(int argc, char *argv[])
{
	end = argc - 2;
	FILE * fp = fopen(argv[1], "wt");
	for(int i = 2; i < argc; i++)
	{
		data[i-2] = argv[i];
	}
	
	powerset(0, 0, fp);
	fprintf(fp,"******************* \n");
	fprintf(fp,"김동규 \nStudent ID: 20175930\n");
	fprintf(fp,"       *         \n");
	fprintf(fp,"     * 28 *         \n");
	fprintf(fp,"       *         \n");	
	fprintf(fp,"$$$$$$$$$$$$$$$$$$$$ \n");
	fclose(fp);

}
