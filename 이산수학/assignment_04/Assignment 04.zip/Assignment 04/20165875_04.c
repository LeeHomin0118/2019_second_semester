
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define MAX_ELEMENT_COUNT 11
#define MAX_STRING_COUNT MAX_ELEMENT_COUNT + 2 
#define EMPTY_SET_CODE ' '
#define LOG_BUFFER_SIZE 32768

int g_lineCounter = 1;
char g_emptySet[2] = { 0, };
char g_logBuffer[LOG_BUFFER_SIZE] = { 0, };

void PrintSigniture()
{
    sprintf( g_logBuffer + strlen( g_logBuffer ), "************************\n" );
    sprintf( g_logBuffer + strlen( g_logBuffer ), "Eun-Kyu Lim\n" );
    sprintf( g_logBuffer + strlen( g_logBuffer ), "Stundent ID : 20165875\n" );
    sprintf( g_logBuffer + strlen( g_logBuffer ), "************************\n" );
}

void MakePowerSet( char* set, const char * argv[], int layerLevel, int argumentCount )
{
    if( layerLevel >= argumentCount )
    {
        if( 0 == strcmp( set, g_emptySet ) )
        {
            
            sprintf(
                    g_logBuffer + strlen( g_logBuffer ),
                    "[%04d] symbol for the empty set\n",
                    g_lineCounter++ );
        }
        else
        {
           
            sprintf( g_logBuffer + strlen( g_logBuffer ), "[%04d]", g_lineCounter++ );
            unsigned long elementCount = strlen( set );
            for( int i = 0; i < elementCount; i++ )
            {
                sprintf( g_logBuffer + strlen( g_logBuffer ), "%c", set[i] );
                if( set[i] != EMPTY_SET_CODE && i != elementCount - 1 )
                {
                    sprintf( g_logBuffer + strlen( g_logBuffer ), ", " );
                }
            }
            sprintf( g_logBuffer + strlen( g_logBuffer ), "\n" );
        }
        return; 
    }
    else
    {
     
        char excludedSet[MAX_STRING_COUNT] = { 0, };
        sprintf( excludedSet, "%s", set );
        MakePowerSet( excludedSet, argv, layerLevel + 1, argumentCount );
        
        
        char includedSet[MAX_STRING_COUNT] = { 0, };
        sprintf( includedSet, "%s", set );
        strcat( includedSet, argv[layerLevel + 1] );
        MakePowerSet( includedSet, argv, layerLevel + 1, argumentCount );
    }
}

void ProcessOutput( const char* filePath )
{
    
    printf( "%s", g_logBuffer );
    
    
    FILE* fileToWrite = fopen( filePath, "wt" );
    if( NULL == fileToWrite )
    {
        printf( "fail to create file for write - %s", filePath );
        return;
    }
    
    fputs( g_logBuffer, fileToWrite );
    fclose( fileToWrite );
}

int main(int argc, const char * argv[])
{
    printf( "argument count - %d\n", argc );
    
    int argumentCount = argc - 1;
    if( argumentCount <= MAX_ELEMENT_COUNT )
    {
        
        sprintf( g_emptySet, "%c", EMPTY_SET_CODE );
        MakePowerSet( g_emptySet, argv, 1, argumentCount );
    }
    else
    {
        
        printf( "Not supported arguments count - %d\n", argumentCount );
    }
    
   
    PrintSigniture();
    
   
    ProcessOutput( argv[1] );
    
    return 0;
}
