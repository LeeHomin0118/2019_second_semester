#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int j = 1;

int powerset(int count_i, int count_p, int element, int *flag, char *argv[], char **ans){
	//공집합일 경우(항상 가장 마지막) 공집합 기호 출력하도록
	if (j == count_p){
		return 0;
	}
	
	if (count_i == element){
		int i;
		for(i = 1; i < count_i; i++){
            if(flag[i] == 1) 
				strcat(ans[j] ,argv[i + 1]);
        }
		j++;
        return 0;
    }
	
	flag[element] = 1;
	powerset(count_i, count_p, element + 1, flag, argv, ans);
	flag[element] = 0;
	powerset(count_i, count_p, element + 1, flag, argv, ans);
}	

int main(int argc, char *argv[]){
	
	FILE *fp;
	
	int i, k;
	int count_i = 0;	//number of input
	int count_p = 1;	//number of powerset
	int *flag;			//for 원소 선택 유무 check
	char **ans;			//부분집합 원소 집어 넣을 이차원 배열
	char print_arr[50];	//file에 저장한 값 프린트하기
	
	fp = fopen(argv[1], "w+");

	for (i = 2; argv[i]; i++){
		count_i++;
	}
	
	//number of powerset's elements
	for (i = 0; i < count_i; i++){
		count_p *= 2;
	}
	
	flag = (int *)calloc(11, sizeof(int));
	
	ans = (char **)calloc(count_p, sizeof(char *));
	for (i = 0; i < count_p; i++){
		ans[i] = (char *)calloc(30, sizeof(char));
	}

	powerset(count_i + 1, count_p, 1, flag, argv, ans);
	
	fprintf(fp, "[%04d] %c\n", 1, 155);
	
	for (i = 1; i < count_p; i++){
		fprintf(fp, "[%04d] ", i + 1);
		int c = strlen(ans[i]);
		for (k = 0; k < c - 1; k++){
			fprintf(fp, "%c, ", ans[i][k]);
		}
		fprintf(fp, "%c", ans[i][c-1]);
		fputs("\n", fp);
	}
	
	fputs("\n", fp);
	fputs("--@*'-'*@--------\n", fp);
	fputs("YouKyeong Kang\n", fp);
	fputs("20172051, CAU\n", fp);
	fputs("--------@*'-'*@--", fp);
	fputs("\n", fp);
	
	fclose(fp);
	
	fp = fopen(argv[1], "r");
	
	while(fgets(print_arr, sizeof(print_arr), fp) != NULL){
		printf("%s", print_arr);
	}
	
	fclose(fp);
	return 0;
	
}