#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>

FILE *fp;

int flag[] = { 0,0,0,0,0,0,0,0,0,0,0 };
int count = 1;
void powerset(int n, int depth, char* argv[])
{
	if (n == depth) {
		int i;
		bool isempty = true;
		fprintf(fp ,"[%04d] ", count++);
		for (i = 1; i < n; i++) {
			if (flag[i] == 1) {
				if (isempty)fprintf(fp,"%s", argv[i + 1]);
				else fprintf(fp, ",%s", argv[i + 1]);
				isempty = false;
			}
		}
		if (isempty) {
			fprintf(fp,"%c", 155);
		}
		fprintf(fp,"\n");
		return;
	}
	flag[depth] = 1;
	powerset(n, depth + 1, argv);
	flag[depth] = 0;
	powerset(n, depth + 1, argv);
}

void main(int argc, char * argv[]) {
	system("chcp 437");
	if ((fp = fopen(argv[1], "w")) == NULL) {
		printf("NO FILE! \n");
		return;
	}
	powerset(argc - 1, 1, argv);
	fprintf(fp, "----------------------\n");
	fprintf(fp, "Baek Jinyoung\n");
	fprintf(fp,"Student ID : 20181945\n");
	fprintf(fp,"----------------------\n");
}