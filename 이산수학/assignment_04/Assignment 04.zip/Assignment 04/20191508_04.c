#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define TRUE 1
#define FALSE 0

int newSubsetId = 1;
int elementsCnt;
char* elements;
FILE* outputFile;
typedef char bool;
void printAllSubsets(bool* existences, int step);
void printSubset(bool* existences);
int main(int argc, char* argv[])
{
	elementsCnt = argc - 2;
	outputFile = fopen(argv[1], "w");
	if (elementsCnt == 0) {
		printSubset(NULL);
	}
	else {
		elements = (char*)malloc(sizeof(char) * elementsCnt);
		for (int i = 0; i < elementsCnt; i++)
			elements[i] = argv[i + 2][0];

		bool* existences = (bool*)malloc(sizeof(bool) * elementsCnt);
		printAllSubsets(existences, 0);
	}
	fprintf(outputFile, "\n");
	fprintf(outputFile, "==========================================================\n");
	fprintf(outputFile, "   _______     __  _ \n");
	fprintf(outputFile, "  / ____\\ \\   / / | |\n");
	fprintf(outputFile, " | (___  \\ \\_/ /  | |\n");
	fprintf(outputFile, "  \\___ \\  \\   /   | |\n");
	fprintf(outputFile, "  ____) |  | | |__| |\n");
	fprintf(outputFile, " |_____/   |_|\\____/ \n");
	fprintf(outputFile, "                     \n");
	fprintf(outputFile, "Name : Shin YeonJin\n");
	fprintf(outputFile, "Student Id: 20191508\n");
	fprintf(outputFile, "==========================================================");
}
void printAllSubsets(bool* existences, int step) {
	for (int i = FALSE; i <= TRUE; i++) {
		existences[step] = i;
		if (step == elementsCnt - 1) {
			printSubset(existences);
		}
		else {
			printAllSubsets(existences, step + 1);
		}
	}
}
void printSubset(bool* existences) {
	bool isEmptySet = TRUE, firstTime = TRUE;
	int subsetId = newSubsetId++;
	fprintf(outputFile, "[%04d] ", subsetId);
	for (int i = 0; i < elementsCnt; i++) {
		if (existences[i]) {
			if (!firstTime) {
				fprintf(outputFile, ", ");
			}
			fprintf(outputFile, "%c", elements[i]);
			firstTime = FALSE;
			isEmptySet = FALSE;
		}
	}
	if (isEmptySet) {
		fprintf(outputFile, "ø\n");
	}
	else {
		fprintf(outputFile, "\n");
	}
}