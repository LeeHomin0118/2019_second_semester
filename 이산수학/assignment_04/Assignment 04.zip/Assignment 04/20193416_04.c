﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <wchar.h> // 유니코드(공집합 기호) 출력을 위한 헤더파일

int powerset(int size, char *filename, char ary[]); // 모든 부분집합을 출력하고 파일로 저장하는 함수 선언

int main(int argc, char** argv)
{
	if (argc != 12) // 입력받은 요소의 개수가 맞지 않으면 프로그램 종료 (12개)
	{
		printf("Check the number of argument"); // 프로그램 종료 안내문 출력
		return 0;	// 프로그램 종료
	}
	
	char chary[10] = { '0' }; // argv의 char 원소들을 저장할 새로운 배열 (크기 10)
	int size = 10;	// 배열 chary에서 실제로 사용할 배열크기

	for (int i = 0; i < size; i++)	// argv의 원소들을 chary에 넣어준다
	{
		chary[i] = *argv[i + 2];
	}

	powerset(size, argv[1], chary);		// 함수를 실행하여 모든 부분집합 출력

	// 작성자 정보 출력
	printf("---------------------------\n");
	printf("Yang Seok-Hwan\n");
	printf("Student ID : 20193416\n\n");
	printf("Too Much Information\n");
	printf("Birthday : 2000.08.16\n");
	printf("Hometown : Nohyeong-dong, Jeju-si\n");
	printf("High School : Namnyeong High School\n");
	printf("---------------------------\n");

	return 0;
}

int powerset(int size, char *filename, char ary[])
{
	// 비트가 1이면, 해당 자리의 원소를 부분집합에 넣고, 0이면 넣지 않는 방식을 사용

	int max = 1 << size;
	int count = 1;			// 일련번호를 표현할 변수

	FILE* fp;
	fp = fopen(filename, "w");

	wchar_t emptyset = 175; // 공집합 기호

	printf("[%04d] ", count); // 공집합은 모든 집합의 부분집합이므로 항상 출력
	wprintf(L"%c\n", emptyset);
	fprintf(fp, "[%04d] ", count); // 파일에도 출력
	fwprintf(fp, L"%c\n", emptyset);
	count += 1;

	for (int i = 1; i < max; i++)
	{
		printf("[%04d] ", count);  // 부분집합 번호 우선 출력
		fprintf(fp, "[%04d] ", count);
		count += 1;

		int flag = 0;	// 부분집합의 원소와 원소 사이의 구분을 위한 변수

		for (int j = 0; j < size; j++)
		{
			if (i & (1 << j))
			{
				if (flag) // 앞에 출력한 원소가 있다면
				{
					printf(", ");	// ', '로 구분
					fputs(", ", fp);
				}
				printf("%c", ary[j]); // 부분집합의 원소 출력
				fprintf(fp, "%c", ary[j]);
				flag = 1;	// 이미 출력한 원소가 있음을 알려준다
			}
		}
		printf("\n");
		fputs("\n", fp);
	}

	// 파일에 작성자 정보 출력
	fputs("---------------------------\n", fp);
	fputs("Yang Seok-Hwan\n", fp);
	fputs("Student ID : 20193416\n\n", fp);
	fputs("Too Much Information\n", fp);
	fputs("Birthday : 2000.08.16\n", fp);
	fputs("Hometown : Nohyeong-dong, Jeju-si\n", fp);
	fputs("High School : Namnyeong High School\n", fp);
	fputs("---------------------------\n", fp);

	fclose(fp);
	return 0;
}