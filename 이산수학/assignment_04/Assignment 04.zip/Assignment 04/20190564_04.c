#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(int argc, char* argv[]) {
	FILE* p1 = fopen(argv[1], "w");

	int num = 1;
	int cardinality = argc - 2;


	for (int i = 1; i <= cardinality + 1; i++) {
		if (i == 1) {
			fprintf(p1, "[%04d] %c\n", num, 155);
			printf("[%04d] %c\n", num++, 155);
		}
		else if (i == 2) {
			for (int j = 2; j <= cardinality + 1; j++) {
				fprintf(p1, "[%04d] %c\n", num, *argv[j]);
				printf("[%04d] %c\n", num++, *argv[j]);
			}
		}
		else if (i == 3) {
			for (int j = 2; j <= cardinality; j++) {
				for (int k = j + 1; k <= cardinality + 1; k++) {
					fprintf(p1, "[%04d] %c, %c\n", num, *argv[j], *argv[k]);
					printf("[%04d] %c, %c\n", num++, *argv[j], *argv[k]);
				}
			}
		}
		else if (i == 4) {
			for (int j = 2; j <= cardinality - 1; j++) {
				for (int k = j+1; k <= cardinality; k++)
					for (int q = k + 1; q <= cardinality + 1; q++) {
						fprintf(p1, "[%04d] %c, %c, %c\n", num, *argv[j], *argv[k], *argv[q]);
						printf("[%04d] %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q]);
					}
			}
		}
		else if (i == 5) {
			for (int j = 2; j <= cardinality - 2; j++) {
				for (int k = j + 1; k <= cardinality - 1; k++)
					for (int q = k + 1; q <= cardinality; q++)
						for (int m = q + 1; m <= cardinality + 1; m++) {
							fprintf(p1, "[%04d] %c, %c, %c, %c\n", num, *argv[j], *argv[k], *argv[q], *argv[m]);
							printf("[%04d] %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m]);
						}
			}
		}
		else if (i == 6) {
			for (int j = 2; j <= cardinality - 3; j++) {
				for (int k = j + 1; k <= cardinality - 2; k++)
					for (int q = k + 1; q <= cardinality - 1; q++)
						for (int m = q + 1; m <= cardinality; m++)
							for (int n = m + 1; n <= cardinality + 1; n++) {
								fprintf(p1, "[%04d] %c, %c, %c, %c, %c\n", num, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n]);
								printf("[%04d] %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n]);
							}
			}
		}
		else if (i == 7) {
			for (int j = 2; j <= cardinality - 4; j++) {
				for (int k = j + 1; k <= cardinality - 3; k++)
					for (int q = k + 1; q <= cardinality - 2; q++)
						for (int m = q + 1; m <= cardinality - 1; m++)
							for (int n = m + 1; n <= cardinality; n++)
								for (int w = n + 1; w <= cardinality + 1; w++) {
									fprintf(p1, "[%04d] %c, %c, %c, %c, %c, %c\n", num, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w]);
									printf("[%04d] %c, %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w]);
								}
			}
		}
		else if (i == 8) {
			for (int j = 2; j <= cardinality - 5; j++) {
				for (int k = j + 1; k <= cardinality - 4; k++)
					for (int q = k + 1; q <= cardinality - 3; q++)
						for (int m = q + 1; m <= cardinality - 2; m++)
							for (int n = m + 1; n <= cardinality - 1; n++)
								for (int w = n + 1; w <= cardinality; w++)
									for (int o = w + 1; o <= cardinality + 1; o++) {
										fprintf(p1, "[%04d] %c, %c, %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o]);
										printf("[%04d] %c, %c, %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o]);
									}
			}
		}
		else if (i == 9) {
			for (int j = 2; j <= cardinality - 6; j++) {
				for (int k = j + 1; k <= cardinality - 5; k++)
					for (int q = k + 1; q <= cardinality - 4; q++)
						for (int m = q + 1; m <= cardinality - 3; m++)
							for (int n = m + 1; n <= cardinality - 2; n++)
								for (int w = n + 1; w <= cardinality - 1; w++)
									for (int o = w + 1; o <= cardinality; o++)
										for (int t = o + 1; t <= cardinality + 1; t++) {
											fprintf(p1, "[%04d] %c, %c, %c, %c, %c, %c, %c, %c\n", num, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o], *argv[t]);
											printf("[%04d] %c, %c, %c, %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o], *argv[t]);
										}
			}
		}
		else if (i == 10) {
			for (int j = 2; j <= cardinality - 7; j++) {
				for (int k = j + 1; k <= cardinality - 6; k++)
					for (int q = k + 1; q <= cardinality - 5; q++)
						for (int m = q + 1; m <= cardinality - 4; m++)
							for (int n = m + 1; n <= cardinality - 3; n++)
								for (int w = n + 1; w <= cardinality - 2; w++)
									for (int o = w + 1; o <= cardinality - 1; o++)
										for (int t = o + 1; t <= cardinality; t++)
											for (int e = t + 1; e <= cardinality + 1; e++) {
												fprintf(p1, "[%04d] %c, %c, %c, %c, %c, %c, %c, %c, %c\n", num, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o], *argv[t], *argv[e]);
												printf("[%04d] %c, %c, %c, %c, %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o], *argv[t], *argv[e]);
											}
			}
		}
		else if (i == 11) {
			for (int j = 2; j <= cardinality - 8; j++) {
				for (int k = j + 1; k <= cardinality - 7; k++)
					for (int q = k + 1; q <= cardinality - 6; q++)
						for (int m = q + 1; m <= cardinality - 5; m++)
							for (int n = m + 1; n <= cardinality - 4; n++)
								for (int w = n + 1; w <= cardinality - 3; w++)
									for (int o = w + 1; o <= cardinality - 2; o++)
										for (int t = o + 1; t <= cardinality - 1; t++)
											for (int e = t + 1; e <= cardinality; e++)
												for (int r = e + 1; r <= cardinality + 1; r++) {
													fprintf(p1, "[%04d] %c, %c, %c, %c, %c, %c, %c, %c, %c, %c\n", num, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o], *argv[t], *argv[e], *argv[r]);
													printf("[%04d] %c, %c, %c, %c, %c, %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o], *argv[t], *argv[e], *argv[r]);
												}
			}
		}
	}

	fclose(p1);

	printf("|---*-*-*-*-*-*-*-*-*---|\n");
	printf("|                       |\n");
	printf("| 20190564   EomChanwoo |\n");
	printf("|                       |\n");
	printf("|---*-*-*-*-*-*-*-*-*---|");

	return 0;
}