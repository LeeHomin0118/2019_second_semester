
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h> 
#include <math.h> 
#include <string.h> 
#include <stdlib.h>
void print_set(int size, char array[][10], int n, FILE *p)
{
	
	static k = 1;
	int i, ele_count = 0;
	//system("chcp 437");
	fprintf(p,"[%04d] ", k++);

	if (k == 2) { fprintf(p,"%d", 0); }

	for (i = 0; i < size; i++)
	{

		if (n % 2 == 1)
		{

			if (ele_count != 0)
			{
				fprintf(p,", ");
			}

			fprintf(p,"%s", array[i+1]);//0 to 1
			ele_count++;
		}

		n = n / 2;
	}
	fprintf(p,"\n");
}
void print_powerset(int size, char array[][10],FILE *p)
{
	
	int i, max = pow(2, size);//�ŵ������Լ� 2^size
	for (i = 0; i < max; i++)
	{

		if (i > 0)
		{
			fprintf(p,"");
		}
		print_set(size, array, i, p);
	}
}

int main(int argc, char *argv[])
{
	FILE *p = fopen("20183968_04.txt", "wt");
	if (0 != p) {
		if (argc >= 13) {
			fprintf(p,"error! it exceeds the maximum!");
			return 0;

		}
		char array[100][10], tmp[10];
		int i, j;
		for (i = 2; i < argc; i++)//1 to 2
		{
			strcpy(array[i - 1], argv[i]);
		}
		for (i = 1; i < argc - 3; i++)//0 to 1,2 to 3
		{
			for (j = i + 1; j < argc - 2; j++)//1 to 2
			{
				if (strcmp(array[i], array[j]) > 0)
				{
					strcpy(tmp, array[i]);
					strcpy(array[i], array[j]);
					strcpy(array[j], tmp);
				}
			}
		}
		print_powerset(argc - 2, array, p);//1 to 2
		fprintf(p, "---student ID : 20183968------\n---cha hyeonho----------------\ndiscrete mathematics\n20191010\n");
		fclose(p);
		return 0;
	}
}