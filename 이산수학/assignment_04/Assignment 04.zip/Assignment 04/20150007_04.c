#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
//typedef struct powerset* ptrPowerset[1024];

typedef struct powerset {
	char sets[30];
	int count;
}powerset;

void insertPowerSet(powerset power[], char c) {
	int count = 0;
	char important[4];
	char temporary[30];
	important[0] = ',';
	important[1] = ' ';
	important[2] = c;
	important[3] = '\0';
	while (power[count].sets[0] != '\0') {
		count++;
	}
	power[count].sets[0] = c;
	power[count].sets[1] = '\0';
	for (int i = 0; i < count; i++) {
		strcpy(temporary, power[i].sets);
		strcat(power[i].sets, important);
		strcpy(power[count + i + 1].sets, power[i].sets);
		strcpy(power[i].sets, temporary);
	}
}


int main() {


	system("chcp 437");  //Ȯ�� �ƽ�Ű�� �������� ����
	unsigned char ascii[2];
	ascii[0] = 155;
	ascii[1] = '\0';
	FILE* fp = fopen("20150007_04.txt", "w");
	char input[100];
	char set[11]; //����
	powerset result[1024];  //�κ�����
	for (int i = 0; i < 1024; i++) {
		result[i].sets[0] = '\0';
	}
	gets(input);
	char* ptr = strtok(input, " ");
	int count = 0;
	for (int i = 0; ptr != NULL; i++) {
		set[i] = *ptr;
		ptr = strtok(NULL, " ");

		count++;

	}
	set[count] = '\0';
	result[0].sets[0] = set[0];
	result[0].sets[1] = '\0';

	for (int i = 1; i < count; i++) {
		insertPowerSet(result, set[i]);
	}
	fputs("[0001]", fp);
	fputs(ascii, fp);
	fputs("\n", fp);
	printf("[0001] %c\n", 155);
	for (int i = 0; ; i++) {
		if (result[i].sets[0] == '\0') {
			break;
		}

		fprintf(fp, "[%.4d]", i + 2);
		fputs(result[i].sets, fp);
		fputs("\n", fp);
		printf("[%.4d] %s\n", i + 2, result[i].sets);
	}
	fputs("---------CopyRight AhnSeungJae----------------\n", fp);
	fputs("Student ID: 20150007\n", fp);
	fputs("Ahn SeungJae\n", fp);
	fputs("---------don't copy my Code-----------------\n", fp);
	fclose(fp);
	printf("---------CopyRight AhnSeungJae----------------\n");
	printf("Student ID: 20150007\n");
	printf("Ahn SeungJae\n");
	printf("---------don't copy my Code-----------------\n");
	system("pause");
	return 0;
}