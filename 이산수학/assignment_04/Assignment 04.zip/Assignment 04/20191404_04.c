#include <stdio.h>

void signature(FILE *fo);

int main(int argc, char** argv)
{
    FILE *fo;
    int n_set = argc - 2;
    
    if ((fo = fopen(argv[1], "wt")) == NULL) {
	printf("Fail to create file\n");
	return 0;
    }
    
    fprintf(fo, "[0001] \u2205\n");
    for (int i = 1; i < 1 << n_set; i++) {
	int is_first = 1;
	fprintf(fo, "[%04d] ", i + 1);
	for (int j = 0; j < n_set; j++) {
	    if (i & (1 << j)) {
		if(is_first) {
		    fprintf(fo, "%c", argv[j + 2][0]);
		    is_first = 0;
		} else {
		    fprintf(fo, ", %c", argv[j + 2][0]);
		}
	    }
	}
	fprintf(fo, "\n");
    }
    signature(fo);
    fclose(fo);
}

void signature(FILE* fo)
{
    fprintf(fo, "\n");
    fprintf(fo, "********************************\n");
    fprintf(fo, "*                              *\n");
    fprintf(fo, "* Name       : Park Younghyeon *\n");
    fprintf(fo, "* Student ID : 20191404        *\n");
    fprintf(fo, "*                              *\n");
    fprintf(fo, "*      00000        00000      *\n");
    fprintf(fo, "*     0     0      0     0     *\n");
    fprintf(fo, "*    0     0 0    0     0 0    *\n");
    fprintf(fo, "*    0    0  0    0    0  0    *\n");
    fprintf(fo, "*    0   0   0    0   0   0    *\n");
    fprintf(fo, "*    0  0    0    0  0    0    *\n");
    fprintf(fo, "*    0 0     0    0 0     0    *\n");
    fprintf(fo, "*     0     0      0     0     *\n");
    fprintf(fo, "*      00000        00000      *\n");
    fprintf(fo, "*                              *\n");
    fprintf(fo, "********************************\n");
}
