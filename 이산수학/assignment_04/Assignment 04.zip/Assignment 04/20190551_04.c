﻿#define _CRT_SECURE_NO_WARNINGS	
#include <stdio.h>
#include <stdlib.h>


int cnt[4] = { 0, };
FILE* fp;




void printcnt()
{
	fprintf(fp,"[");
	for (int i = 0; i < 4; i++)
	{
		fprintf(fp,"%d", cnt[i]);
	}
	fprintf(fp,"] ");
}
void addcnt()
{
	cnt[3]++;
	for (int i = 3; i >= 1; i--)
	{
		cnt[i - 1] += cnt[i] / 10;
		cnt[i] = cnt[i] % 10;
	}
}

void subset(int n, char* argv[], int argc, int t, int* flag, int before)
{
	
	
	if (n == 0)
	{
		printcnt();

		fprintf(fp,"ø\n");
		addcnt();
		return;
	}
	if (n == t)
	{

		printcnt();
		for (int i = 0; i < argc - 1; i++)
		{
			if (flag[i] == 1)
			{
				fprintf(fp,"%s ", argv[i + 1]);
			}
		}
		fprintf(fp,"\n");

		addcnt();
		return;
	}
	for (int i = before + 1; i < argc - 1; i++)
	{
		if (flag[i] != 1)
		{
			flag[i] = 1;
			subset(n, argv, argc, t + 1, flag, i);
			flag[i] = 0;
		}
	}
}

int main(int argc, char* argv[])
{

	if ((fp = fopen(argv[1], "w")) == NULL) {
		printf("입력 실패-종료\n");
		return 1;
	}

	

	for (int i = 0; i < argc; i++)
	{
		int* flag = (int*)calloc(argc, sizeof(int) * argc);
		subset(i, argv, argc, 0, flag, 0);
		free(flag);
	}

	fprintf(fp,"----------------------!!!!!!\n");
	fprintf(fp,"Hyo Chang Yoo\n");
	fprintf(fp,"Student ID : 20190551\n");
	fprintf(fp,"----------------------!!!!!!\n");
	
	fclose(fp);

	return 0;
}