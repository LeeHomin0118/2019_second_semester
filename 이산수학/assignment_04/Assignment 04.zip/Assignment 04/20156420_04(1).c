//
//  main.c
//  assignment1
//
//  Created by Alex Park on 27/09/2019.
//  Copyright © 2019 Alex Park. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
char *data[20];

int main(int argc, char *argv[])
{
    FILE * fp = fopen(argv[1], "wt");

    fprintf(fp,"[0001] ∅ \n");
    int max = (1<<(argc-2));
    for (int i = 1; i < max; i++)
    {
        fprintf(fp,"[%04d] ",i);
        for (int j =1; j<argc;j++){
            if(i & (1<<(j-2))) fprintf(fp,"%s ",argv[j]);
//            if (j==argc-1) break;
//            if(i & (1<<(j-1)) && i>max/2) printf(", ");
        }
        fprintf(fp,"\n");
    }
    
    fprintf(fp,"Created by Alex Park on 27/09/2019.\n");
    fprintf(fp,"Copyright © 2019 Alex Park. All rights reserved.\n");


    
   
    return 0;
}
