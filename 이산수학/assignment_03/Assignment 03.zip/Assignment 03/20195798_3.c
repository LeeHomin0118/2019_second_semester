﻿

char array[Length] = { 'a','b' };
int nums[Length];

void fun(int index)
{
	if (index == Length)
	{
		printf("{ ");
		int i;
		for (i = 0; i < Length; index] = 0;
	fun(index + 1);
	nums[index] = 1;
	fun(index + 1);
}

int main(void)
{
	fun(0);
	return 0;
}