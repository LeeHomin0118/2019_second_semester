﻿#include <stdio.h>
#include <math.h>	// pow()사용을 위함
#include <stdlib.h>

void powerset(char bit, char list[], int len, int num);

void main(int argc, char * argv[])
{
	char * list = (char*)malloc(sizeof(char)*argc);

	for (int i = 1; i < argc; i++) {
		list[i] = (char)*argv[i];
	}

	char bit = 1;
	int num = 1; // 숫자 출력을 위한 변수.
	powerset(bit, list, argc, num);
}

// 001->a, 010->b, 100->c ... 000->공집합
void powerset(char bit, char list[], int len, int num)
{
	int i;
	printf("[%04d] ", num);
	for (i = 0; i < len; i++)	// 각 순환별 MAX번 반복한다.
	{

		// bit 연산
		// 1을 왼쪽으로 i번 쉬프트 한다.
		if (bit & (1 << i))
		{
			num++;
			// 1 << i는 각 실행별 001, 010, 100으로 된다.
			printf("%c ", list[i]);

		}
	}
	printf("\n");

	/* bit값이 2의 3승, 즉 8이 될 때까지 recursion */
	bit++;

	if (bit == pow(2, len))
		// bit가 2의 MAX승이 되면
	{
		return;
	}

	// 값이 1증가한 bit를 다시 매개변수로 넘겨준다.
	powerset(bit, list, len, num);
}
