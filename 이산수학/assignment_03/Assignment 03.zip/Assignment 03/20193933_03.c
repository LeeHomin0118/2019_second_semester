#include <stdio.h>
#include <string.h>


char str1[20];

void powerset(int n)
{
	int i, j;
	int max = 1 << n;
	int Delete1 = 0x7F;
	for (i = 0; i < max; i++) {
		printf("[%04d] ",i+1);
		if (i == 0) {
			printf("%c", 155);
		}
		
		for (j = 0; j < n; j++) {
			if ((i & (1 << j)) &&  (i != (1<<j))) {
				printf("%c", str1[2*j]);
				if ((i>>1) >= (1 << j)) {
					printf(", ");
				}
			}
			else if ((i & (1 << j)) && (i == (1 << j))) {
				printf("%c", str1[2 * j]);
			}
		}
		printf("\n");
	}
}

int main()
{	
	
	int length;
	int k;

	gets_s(str1,sizeof(str1));
	length = strlen(str1);
	k = length / 2 + 1;

	powerset(k);

	printf("*****************\n");
	printf("  Discretemathematics\n");
	printf("   Jo Eon Wook \n");
	printf("    20193933 \n");
	printf("*****************\n");
	return 0;
}