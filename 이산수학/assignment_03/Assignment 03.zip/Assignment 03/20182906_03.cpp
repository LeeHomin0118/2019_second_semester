#include <stdio.h>
#include <windows.h>

int subset[] = {1,2,3,4,5,6,7,8,9,10};
int check[] = {0,0,0,0,0,0,0,0,0,0};

void set(int n,int index)
{
	if(n == index)
	{
		int i;
		printf("{");
		for(i=0;i<n;i++)
		{
			
			if(check[i]==0)
			{
				printf("%c",155);
			}
			if(check[i]==1)
			{
				printf("%d",subset[i]);
			}
		}
		printf("}\n");
		return;
	}
	check[index]=1;
	set(n,index+1);
	check[index]=0;
	set(n,index+1);
}

int main()
{
	set(10,0);
	
	printf("�١١١١١١١١١١١١١�\n");
	printf("��   ����� 20182906      ��\n");
	printf("�١١١١١١١١١١١١١�\n");
	return 0;
	system("pause");
}
