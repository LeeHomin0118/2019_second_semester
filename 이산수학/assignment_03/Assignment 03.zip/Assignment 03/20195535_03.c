#include <stdio.h>
#include <stdlib.h>


int try_count(int num) {	//POWER SET ���� count
	int result = 1;

	for (int i = 0; i < num - 1; i++) {
		result *= 2;
	}

	return result;
}

void bit_count(char *arr, int i) {	//bit ����
	arr[i]++;

	if (arr[i] == 2) {
		arr[i] = 0;
		bit_count(arr, i + 1);
	}

	return;
}

void init_arr(char *arr, int num) {	//�迭 0���� �ʱ�ȭ

	for (int i = 0; i < num - 1; i++) {
		arr[i] = 0;
	}

}

int main(int argc, char* argv[]) {
	int tries, count = 0;

	int c = 155;

	char *exist = (char *)malloc(argc - 1);	//set�� element�� �����ϴ� �� ǥ���ϴ� �迭, ���� : 1, ���� : 0

	tries = try_count(argc);
	
	init_arr(exist, argc);

	for (int i = 1; i <= tries; i++) {

		count = 0;

		printf("[%04d] ", i);

		for (int j = 0; j < argc - 1; j++) {
		
			if (exist[j] == 1 && count == 0) {	//�� ó�� element�� ', '����
				
				printf("%s", argv[j + 1]);
				count++;
			
			} else if(exist[j] == 1 && count != 0){	//�� ��° ��� ���� ', '�ʿ�
				
				printf(", %s", argv[j + 1]);
				count++;
			
			}

		}	//end of for(j)
		
		if (count == 0) {
			printf("%c", c);
		}

		printf("\n");
		 
		if (i != tries) {
			bit_count(exist, 0);
		}
	}	//end of for(i)

	free(exist);

	printf("  _________________________\n");
	printf(" |                         |\n");
	printf("<   Kim Hee - min          |\n");
	printf(" |                         |\n");
	printf(" |  Student ID : 20195535  |\n");
	printf(" |_________________________|\n");


	return 0;
}