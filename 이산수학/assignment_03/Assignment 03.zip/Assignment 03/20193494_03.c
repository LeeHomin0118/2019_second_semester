#include <stdio.h>
#include <math.h>
#include <wchar.h>
#include <locale.h>

#define bitcheck(n, digit) (n>>(digit)) % 2


int main(int argc, char *argv[]) {
	setlocale(LC_CTYPE, "");
	wchar_t empty = 0x00D8;
	int oncnt;
	if (argc > 10) {
		printf("Too many operator.");
		return 0;
	}

	for (int num = 0; num < pow(2, argc - 1); num++) {
		oncnt = 0;
		printf("[%04d] : ", num);
		if (num == 0)
			 wprintf(L"%lc", empty);
		else {
			for (int i = 0; i < (argc - 1); i++) {
				if (bitcheck(num, i) != 0) {
					if (oncnt > 0)
						printf(", ");
					printf("%s", argv[i + 1]);
					oncnt++;
				}
			}
		}
		printf("\n");
	}


	printf("\n*************************\n*  I'm Seo Hyeong Moon! *\n*        Hi Hello       *\n*************************");
}