#include <stdio.h>


int main(int argc, char* argv[])

{

	int sum = 1;

	int a = 1;

	printf("[%04d]%c\n", sum, 155);

	sum++;



	if (argc - 1 >= a) //1

	{

		for (int i = 1; i < argc; i++)

		{

			printf("[%04d]%c\n", sum, argv[i][0]);

			sum++;

		}

	}

	a++;



	if (argc - 1 >= a) //2

	{

		for (int i = 1; i < argc; i++)

		{

			for (int j = i + 1; j < argc; j++)

			{

				printf("[%04d]%c, %c\n", sum, argv[i][0], argv[j][0]);

				sum++;

			}

		}

	}

	a++;



	if (argc - 1 >= a) //3

	{

		for (int i = 1; i < argc; i++)

		{

			for (int j = i + 1; j < argc; j++)

			{

				for (int k = j + 1; k < argc; k++)

				{

					printf("[%04d]%c, %c, %c\n", sum, argv[i][0], argv[j][0], argv[k][0]);

					sum++;

				}

			}

		}

	}

	a++;



	if (argc - 1 >= a) // 4

	{

		for (int i = 1; i < argc; i++)

		{

			for (int j = i + 1; j < argc; j++)

			{

				for (int k = j + 1; k < argc; k++)

				{

					for (int l = k + 1; l < argc; l++)

					{

						printf("[%04d]%c, %c, %c, %c\n", sum, argv[i][0], argv[j][0], argv[k][0], argv[l][0]);

						sum++;

					}

				}

			}

		}

	}

	a++;

	if (argc - 1 >= a) // 5

	{

		for (int i = 1; i < argc; i++)

		{

			for (int j = i + 1; j < argc; j++)

			{

				for (int k = j + 1; k < argc; k++)

				{

					for (int l = k + 1; l < argc; l++)

					{

						for (int m = l + 1; m < argc; m++)

						{

							printf("[%04d]%c, %c, %c, %c, %c\n", sum, argv[i][0], argv[j][0], argv[k][0], argv[l][0], argv[m][0]);

							sum++;

						}

					}

				}

			}

		}

	}

	a++;

	if (argc - 1 >= a) // 6

	{

		for (int i = 1; i < argc; i++)

		{

			for (int j = i + 1; j < argc; j++)

			{

				for (int k = j + 1; k < argc; k++)

				{

					for (int l = k + 1; l < argc; l++)

					{

						for (int m = l + 1; m < argc; m++)

						{

							for (int n = m + 1; n < argc; n++)

							{

								printf("[%04d]%c, %c, %c, %c, %c, %c\n", sum, argv[i][0], argv[j][0], argv[k][0], argv[l][0], argv[m][0], argv[n][0]);

								sum++;

							}

						}

					}

				}

			}

		}

	}

	a++;



	if (argc - 1 >= a) // 7

	{

		for (int i = 1; i < argc; i++)

		{

			for (int j = i + 1; j < argc; j++)

			{

				for (int k = j + 1; k < argc; k++)

				{

					for (int l = k + 1; l < argc; l++)

					{

						for (int m = l + 1; m < argc; m++)

						{

							for (int n = m + 1; n < argc; n++)

							{

								for (int o = n + 1; o < argc; o++)

								{

									printf("[%04d]%c, %c, %c, %c, %c, %c, %c\n", sum, argv[i][0], argv[j][0], argv[k][0], argv[l][0], argv[m][0], argv[n][0], argv[o][0]);

									sum++;

								}

							}

						}

					}

				}

			}

		}

	}

	a++;



	if (argc - 1 >= a) // 8

	{

		for (int i = 1; i < argc; i++)

		{

			for (int j = i + 1; j < argc; j++)

			{

				for (int k = j + 1; k < argc; k++)

				{

					for (int l = k + 1; l < argc; l++)

					{

						for (int m = l + 1; m < argc; m++)

						{

							for (int n = m + 1; n < argc; n++)

							{

								for (int o = n + 1; o < argc; o++)

								{

									for (int p = o + 1; p < argc; p++)

									{

										printf("[%04d]%c, %c, %c, %c, %c, %c, %c, %c\n", sum, argv[i][0], argv[j][0], argv[k][0], argv[l][0], argv[m][0], argv[n][0], argv[o][0], argv[p][0]);

										sum++;

									}

								}

							}

						}

					}

				}

			}

		}

	}

	a++;



	if (argc - 1 >= a) // 9

	{

		for (int i = 1; i < argc; i++)

		{

			for (int j = i + 1; j < argc; j++)

			{

				for (int k = j + 1; k < argc; k++)

				{

					for (int l = k + 1; l < argc; l++)

					{

						for (int m = l + 1; m < argc; m++)

						{

							for (int n = m + 1; n < argc; n++)

							{

								for (int o = n + 1; o < argc; o++)

								{

									for (int p = o + 1; p < argc; p++)

									{

										for (int q = p + 1; q < argc; q++)

										{

											printf("[%04d]%c, %c, %c, %c, %c, %c, %c, %c, %c\n", sum, argv[i][0], argv[j][0], argv[k][0], argv[l][0], argv[m][0], argv[n][0], argv[o][0], argv[p][0], argv[q][0]);

											sum++;

										}

									}

								}

							}

						}

					}

				}

			}

		}

	}

	a++;



	if (argc - 1 >= a) // 10

	{

		for (int i = 1; i < argc; i++)

		{

			for (int j = i + 1; j < argc; j++)

			{

				for (int k = j + 1; k < argc; k++)

				{

					for (int l = k + 1; l < argc; l++)

					{

						for (int m = l + 1; m < argc; m++)

						{

							for (int n = m + 1; n < argc; n++)

							{

								for (int o = n + 1; o < argc; o++)

								{

									for (int p = o + 1; p < argc; p++)

									{

										for (int q = p + 1; q < argc; q++)

										{

											for (int r = q + 1; r < argc; r++)

											{

												printf("[%04d]%c, %c, %c, %c, %c, %c, %c, %c, %c, %c\n", sum, argv[i][0], argv[j][0], argv[k][0], argv[l][0], argv[m][0], argv[n][0], argv[o][0], argv[p][0], argv[q][0], argv[r][0]);

												sum++;

											}

										}

									}

								}

							}

						}

					}

				}

			}

		}

	}

	a++;





	printf("\n--------------------------------\nNAME :  KIM NAMJU\nStudent Id : 20190270\n--------------------------------");

	return 0;

}