//
//  main.c
//  assignment1
//
//  Created by Alex Park on 27/09/2019.
//  Copyright © 2019 Alex Park. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{
    printf("∅\n");
    for (int i = 1; i < argc; i++)
    {
        
        for (int j =0; j<argc-i;j++){
            for (int k=1;k<i+1;k++){
                printf("%s ", argv[j+k]);
            }
            printf("\n");
        }
    }

    
    
    printf("Created by Alex Park on 27/09/2019.\n");
    printf("Copyright © 2019 Alex Park. All rights reserved.\n");
    return 0;
}
