#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char *argv[])
{
	int i, j, k, l=1;
	int cnt = 2;
	int num = 1;

	printf("[0001] %c\n", (char)155);	//65로 했을때는 A가 찍히는데 155는 읽지 못하는거 같습니

	for (i = 1; i < argc; i++)
	{
		
		cnt = 2;
		for(j = 1; j < argc; j++)
		{	
			num++;
				if (num/10 ==0) printf("[000%d]", num);
				else if (num/10 ==1) printf("[00%d]", num);
				else if (num/10 ==2) printf("[0%d]", num);
				else if (num/10 ==3) printf("[%d]", num);
			for(k=i; k <= j; k++)
			{	
				printf("%s ", argv[k]);
			}
			printf("\n");
		}
		for(j = i+2; j < argc; j++)
		{
			num++;
				if (num/10 ==0) printf("[000%d]", num);
				else if (num/10 ==1) printf("[00%d]", num);
				else if (num/10 ==2) printf("[0%d]", num);
				else if (num/10 ==3) printf("[%d]", num);
			for(k=i; k < j; k+=cnt)
			{
				printf("%s ", argv[k]);
				for(l = k+2; l <=j; l++)
				{
					printf("%s ", argv[l]);
				}
			}
			printf("\n");
			cnt++;
		}
	}

	printf("******************* \n");
	printf("김동규 \nStudent ID: 20175930\n");
	printf("       *         \n");
	printf("     * 28 *         \n");
	printf("       *         \n");	
	printf("$$$$$$$$$$$$$$$$$$$$ \n");
}	
