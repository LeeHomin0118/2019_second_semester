#include<stdio.h>
#include<stdlib.h>


int flag[] = { 0,0,0,0,0,0,0,0,0,0,0 };
int count = 1;
void powerset(int n, int depth, char** argv)
{
	if (n == depth) {
		int i;
		bool isempty = true;
		printf("[%04d] ", count++);
		for (i = 0; i < n; i++) {
			if (flag[i] == 1) {
				if (isempty)printf("%s", argv[i + 1]);
				else printf(",%s", argv[i + 1]);
				isempty = false;
			}
		}
		if (isempty) {
			printf("%c", 155);
		}
		printf("\n");
		return;
	}
	flag[depth] = 1;
	powerset(n, depth + 1, argv);
	flag[depth] = 0;
	powerset(n, depth + 1, argv);
}

int main(int argc, char** argv) {
	system("chcp 437");
	powerset(argc - 1, 0, argv);
	printf("----------------------\n");
	printf("Baek Jinyoung\n");
	printf("Student ID : 20181945\n");
	printf("----------------------\n");
}
