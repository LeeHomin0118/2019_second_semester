#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h> 
#include <math.h> 
#include <string.h> 
#include <stdlib.h>
void print_set(int size, char array[][10], int n)
{
	static k = 1;
	int i, ele_count = 0;
	system("chcp 437");
	printf("[%04d] ",k++);
	
	if (k==2) { printf("%c",155); }

	for (i = 0; i < size; i++)
	{
		
		if (n % 2 == 1)
		{
			
			if (ele_count != 0)
			{
				printf(", ");
			}

			printf("%s", array[i]);
			ele_count++;
		}
		
		n = n / 2;
	}
	printf("\n");
}
void print_powerset(int size, char array[][10])
{
	int i, max = pow(2, size);//�ŵ������Լ� 2^size
	for (i = 0; i < max; i++)
	{
		
		if (i > 0)
		{
			printf("");
		}
		print_set(size, array, i);
	}
}
int main(int argc, char *argv[])
{
	if (argc >= 12) {
		printf("error! it exceeds the maximum!");
		return 0;

	}
	char array[100][10], tmp[10];
	int i, j;
	for (i = 1; i < argc; i++)
	{
		strcpy(array[i - 1], argv[i]);
	}
	for (i = 0; i < argc - 2; i++)
	{
		for (j = i + 1; j < argc - 1; j++)
		{
			if (strcmp(array[i], array[j]) > 0)
			{
				strcpy(tmp, array[i]);
				strcpy(array[i], array[j]);
				strcpy(array[j], tmp);
			}
		}
	}
	print_powerset(argc - 1, array);
	printf("---student ID : 20183968------\n---cha hyeonho----------------\ndiscrete mathematics\n20191010\n");
	return 0;
}
//argc==7���� ������� (practice)
/*int main(int argc, char *argv[]) {
	int i = 0, k = 0;
	printf("[0001] a symbol for the empty set\n");

	if (argc == 2) {
		while (argv[i + 1] != 0) {
			printf("[%04d] %s\n", i + 2, argv[i + 1]);
			i++;
		}
	}
	if (argc == 3) {
		while (argv[i + 1] != 0) {
			printf("[%04d] %s\n", i + 2, argv[i + 1]);
			i++;
		}

		printf("[%04d] %s, %s\n", i + 2, argv[k + 1], argv[k + 2]);


	}
	if (argc == 4) {
		while (argv[i + 1] != 0) {
			printf("[%04d] %s\n", i + 2, argv[i + 1]);
			i++;
		}


		printf("[%04d] %s, %s\n", i + 2, argv[k + 1], argv[k + 2]);
		printf("[%04d] %s, %s\n", i + 3, argv[k + 1], argv[k + 3]);
		printf("[%04d] %s, %s\n", i + 4, argv[k + 2], argv[k + 3]);

		printf("[%04d] %s, %s, %s\n", i + 5, argv[k + 1], argv[k + 2], argv[k + 3]);
	}
	if (argc == 5) {
		while (argv[i + 1] != 0) {
			printf("[%04d] %s\n", i + 2, argv[i + 1]);
			i++;
		}
		printf("[%04d] %s, %s\n", i + 2, argv[k + 1], argv[k + 2]);
		printf("[%04d] %s, %s\n", i + 3, argv[k + 1], argv[k + 3]);
		printf("[%04d] %s, %s\n", i + 4, argv[k + 1], argv[k + 4]);
		printf("[%04d] %s, %s\n", i + 5, argv[k + 2], argv[k + 3]);
		printf("[%04d] %s, %s\n", i + 6, argv[k + 2], argv[k + 4]);
		printf("[%04d] %s, %s\n", i + 7, argv[k + 3], argv[k + 4]);

		printf("[%04d] %s, %s, %s\n", i + 8, argv[k + 1], argv[k + 2], argv[k + 3]);
		printf("[%04d] %s, %s, %s\n", i + 9, argv[k + 1], argv[k + 2], argv[k + 4]);
		printf("[%04d] %s, %s, %s\n", i + 10, argv[k + 1], argv[k + 3], argv[k + 4]);
		printf("[%04d] %s, %s, %s\n", i + 11, argv[k + 2], argv[k + 3], argv[k + 4]);

		printf("[%04d] %s, %s, %s, %s\n", i + 12, argv[k + 1], argv[k + 2], argv[k + 3], argv[k + 4]);

	}
	if (argc == 6) {
		while (argv[i + 1] != 0) {
			printf("[%04d] %s\n", i + 2, argv[i + 1]);
			i++;
		}
		printf("[%04d] %s, %s\n", i + 2, argv[k + 1], argv[k + 2]);
		printf("[%04d] %s, %s\n", i + 3, argv[k + 1], argv[k + 3]);
		printf("[%04d] %s, %s\n", i + 4, argv[k + 1], argv[k + 4]);
		printf("[%04d] %s, %s\n", i + 5, argv[k + 1], argv[k + 5]);
		printf("[%04d] %s, %s\n", i + 6, argv[k + 2], argv[k + 3]);
		printf("[%04d] %s, %s\n", i + 7, argv[k + 2], argv[k + 4]);
		printf("[%04d] %s, %s\n", i + 8, argv[k + 2], argv[k + 5]);
		printf("[%04d] %s, %s\n", i + 9, argv[k + 3], argv[k + 4]);
		printf("[%04d] %s, %s\n", i + 10, argv[k + 3], argv[k + 5]);
		printf("[%04d] %s, %s\n", i + 11, argv[k + 4], argv[k + 5]);

		printf("[%04d] %s, %s, %s\n", i + 12, argv[k + 1], argv[k + 2], argv[k + 3]);
		printf("[%04d] %s, %s, %s\n", i + 13, argv[k + 1], argv[k + 2], argv[k + 4]);
		printf("[%04d] %s, %s, %s\n", i + 14, argv[k + 1], argv[k + 2], argv[k + 5]);
		printf("[%04d] %s, %s, %s\n", i + 15, argv[k + 1], argv[k + 3], argv[k + 4]);
		printf("[%04d] %s, %s, %s\n", i + 16, argv[k + 1], argv[k + 3], argv[k + 5]);
		printf("[%04d] %s, %s, %s\n", i + 20, argv[k + 1], argv[k + 4], argv[k + 5]);
		printf("[%04d] %s, %s, %s\n", i + 17, argv[k + 2], argv[k + 3], argv[k + 4]);
		printf("[%04d] %s, %s, %s\n", i + 18, argv[k + 2], argv[k + 3], argv[k + 5]);
		printf("[%04d] %s, %s, %s\n", i + 19, argv[k + 2], argv[k + 4], argv[k + 5]);
		printf("[%04d] %s, %s, %s\n", i + 21, argv[k + 3], argv[k + 4], argv[k + 5]);

		printf("[%04d] %s, %s, %s, %s\n", i + 22, argv[k + 1], argv[k + 2], argv[k + 3], argv[k + 4]);
		printf("[%04d] %s, %s, %s, %s\n", i + 23, argv[k + 1], argv[k + 2], argv[k + 3], argv[k + 5]);
		printf("[%04d] %s, %s, %s, %s\n", i + 24, argv[k + 1], argv[k + 2], argv[k + 4], argv[k + 5]);
		printf("[%04d] %s, %s, %s, %s\n", i + 25, argv[k + 1], argv[k + 3], argv[k + 4], argv[k + 5]);
		printf("[%04d] %s, %s, %s, %s\n", i + 26, argv[k + 2], argv[k + 3], argv[k + 4], argv[k + 5]);

		printf("[%04d] %s, %s, %s, %s, %s\n", i + 27, argv[k + 1], argv[k + 2], argv[k + 3], argv[k + 4], argv[k + 5]);

	}
	if (argc == 7) {
		while (argv[i + 1] != 0) {
			printf("[%04d] %s\n", i + 2, argv[i + 1]);
			i++;
		}
		for (int j = 0; j < 5; j++, i++) {
			printf("[%04d] %s, %s\n", i + 2, argv[k + 1], argv[k + j + 2]);

		}
		//printf("[%04d] %s, %s\n", i + 2, argv[k + 1], argv[k + 2]);
		//printf("[%04d] %s, %s\n", i + 3, argv[k + 1], argv[k + 3]);
		//printf("[%04d] %s, %s\n", i + 4, argv[k + 1], argv[k + 4]);
		//printf("[%04d] %s, %s\n", i + 5, argv[k + 1], argv[k + 5]);
		for (int j = 0; j < 4; j++, i++) {
			printf("[%04d] %s, %s\n", i + 2, argv[k + 2], argv[k + j + 3]);

		}
		//printf("[%04d] %s, %s\n", i + 6, argv[k + 2], argv[k + 3]);
		//printf("[%04d] %s, %s\n", i + 7, argv[k + 2], argv[k + 4]);
		//printf("[%04d] %s, %s\n", i + 8, argv[k + 2], argv[k + 5]);
		for (int j = 0; j < 3; j++, i++) {
			printf("[%04d] %s, %s\n", i + 2, argv[k + 3], argv[k + j + 4]);

		}
		//printf("[%04d] %s, %s\n", i + 9, argv[k + 3], argv[k + 4]);
		//printf("[%04d] %s, %s\n", i + 10, argv[k + 3], argv[k + 5]);
		for (int j = 0; j < 2; j++, i++) {
			printf("[%04d] %s, %s\n", i + 2, argv[k + 4], argv[k + j + 5]);

		}
		//printf("[%04d] %s, %s\n", i + 11, argv[k + 4], argv[k + 5]);
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s\n", i + 2, argv[k + 5], argv[k + j + 6]);

		}
		//6C3
		for (int j = 0; j < 4; j++, i++) {
			printf("[%04d] %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 2], argv[k + j + 3]);

		}

		for (int j = 0; j < 3; j++, i++) {
			printf("[%04d] %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 3], argv[k + j + 4]);

		}
		for (int j = 0; j < 2; j++, i++) {
			printf("[%04d] %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 4], argv[k + j + 5]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 5], argv[k + j + 6]);

		}
		for (int j = 0; j < 3; j++, i++) {
			printf("[%04d] %s, %s, %s\n", i + 2, argv[k + 2], argv[k + 3], argv[k + j + 4]);

		}
		for (int j = 0; j < 2; j++, i++) {
			printf("[%04d] %s, %s, %s\n", i + 2, argv[k + 2], argv[k + 4], argv[k + j + 5]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s\n", i + 2, argv[k + 2], argv[k + 5], argv[k + j + 6]);

		}
		for (int j = 0; j < 2; j++, i++) {
			printf("[%04d] %s, %s, %s\n", i + 2, argv[k + 3], argv[k + 4], argv[k + j + 5]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s\n", i + 2, argv[k + 3], argv[k + 5], argv[k + j + 6]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s\n", i + 2, argv[k + 4], argv[k + 5], argv[k + j + 6]);

		}
		//6C4
		for (int j = 0; j < 3; j++, i++) {
			printf("[%04d] %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 2], argv[k + 3], argv[k + j + 4]);

		}
		for (int j = 0; j < 2; j++, i++) {
			printf("[%04d] %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 2], argv[k + 4], argv[k + j + 5]);

		}
		for (int j = 0; j < 2; j++, i++) {
			printf("[%04d] %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 3], argv[k + 4], argv[k + j + 5]);

		}
		for (int j = 0; j < 2; j++, i++) {
			printf("[%04d] %s, %s, %s, %s\n", i + 2, argv[k + 2], argv[k + 3], argv[k + 4], argv[k + j + 5]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 2], argv[k + 5], argv[k + j + 6]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 4], argv[k + 5], argv[k + j + 6]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s\n", i + 2, argv[k + 2], argv[k + 4], argv[k + 5], argv[k + j + 6]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s\n", i + 2, argv[k + 3], argv[k + 4], argv[k + 5], argv[k + j + 6]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 3], argv[k + 5], argv[k + j + 6]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s\n", i + 2, argv[k + 2], argv[k + 3], argv[k + 5], argv[k + j + 6]);

		}
		//6C5
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 2], argv[k + 3], argv[k + 4], argv[k + 5]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 2], argv[k + 3], argv[k + 4], argv[k + 6]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 3], argv[k + 4], argv[k + 5], argv[k + 6]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 2], argv[k + 4], argv[k + 5], argv[k + 6]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 2], argv[k + 3], argv[k + 5], argv[k + 6]);

		}
		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s, %s\n", i + 2, argv[k + 2], argv[k + 3], argv[k + 4], argv[k + 5], argv[k + 6]);

		}

		for (int j = 0; j < 1; j++, i++) {
			printf("[%04d] %s, %s, %s, %s, %s, %s\n", i + 2, argv[k + 1], argv[k + 2], argv[k + 3], argv[k + 4], argv[k + 5], argv[k + 6]);

		}

	}*/