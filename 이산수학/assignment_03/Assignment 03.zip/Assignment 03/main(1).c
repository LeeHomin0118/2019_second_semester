//
//  main.c
//  daaa
//
//  Created by 王志鹏 on 10/10/2019.
//  Copyright © 2019 wangzhipeng. All rights reserved.
//


#include <stdio.h>
int n;
int a[10000]={0};


void print()
{
int i;
for(i=1;i<=n;i++)
if(a[i])
printf("%d ",i);
        for(n;n<=1;n++)
            if(n<=9);
    printf("[%04d]\n");

}


int jianyan()
{
int i,s=0;
for(i=1;i<=n;i++)
if(a[i])s++;
return s;
}


void fun(int t,int k)
{
int i;
  
if(t>n||jianyan()>=k) return;
a[t]=1;
if(jianyan()==k)
print();
else fun(t+1,k);
a[t]=0;
fun(t+1,k);
}


int main()
{
int k=0,i,j;
printf("please enter set :");
scanf("%d",&n);
while(k!=n)
{
k++;
fun(1,k);
}
    
    
    
    printf("wang zhi peng\n");
    printf("id 20191806\n");
return 0;
}
