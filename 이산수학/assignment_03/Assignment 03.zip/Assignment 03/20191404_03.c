#include <stdio.h>

void signature();

int main(int argc, char** argv)
{
    int n_set = argc - 1;
    printf("[0001] \u2205\n");
    for (int i = 1; i < 1 << n_set; i++) {
	int is_first = 1;
	printf("[%04d] ", i + 1);
	for (int j = 0; j < n_set; j++) {
	    if (i & (1 << j)) {
		if(is_first) {
		    printf("%c", argv[j + 1][0]);
		    is_first = 0;
		} else {
		    printf(", %c", argv[j + 1][0]);
		}
	    }
	}
	printf("\n");
    }
    signature();
}

void signature()
{
    printf("\n");
    printf("********************************\n");
    printf("*                              *\n");
    printf("* Name       : Park Younghyeon *\n");
    printf("* Student ID : 20191404        *\n");
    printf("*                              *\n");
    printf("*      00000        00000      *\n");
    printf("*     0     0      0     0     *\n");
    printf("*    0     0 0    0     0 0    *\n");
    printf("*    0    0  0    0    0  0    *\n");
    printf("*    0   0   0    0   0   0    *\n");
    printf("*    0  0    0    0  0    0    *\n");
    printf("*    0 0     0    0 0     0    *\n");
    printf("*     0     0      0     0     *\n");
    printf("*      00000        00000      *\n");
    printf("*                              *\n");
    printf("********************************\n");
}
