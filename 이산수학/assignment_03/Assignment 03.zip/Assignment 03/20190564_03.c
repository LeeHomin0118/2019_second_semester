#include <stdio.h>

int main(int argc, char* argv[11]) {
	int num = 1;
	int cardinality = argc - 1;


	for (int i = 0; i <= cardinality ; i++) {
		if (i == 0)
			printf("[%04d] %c\n",num++, 155);
		else if (i == 1) {
			for (int j = 1; j <= cardinality; j++)
					printf("[%04d] %c\n", num++, *argv[j]);
		}
		else if (i == 2) {
			for (int j = 1; j <= cardinality - 1; j++) {
				for (int k = j + 1; k <= cardinality; k++)
						printf("[%04d] %c, %c\n", num++, *argv[j], *argv[k]);
			}
		}
		else if (i == 3) {
			for (int j = 1; j <= cardinality - 2; j++) {
				for (int k = j+1; k <= cardinality - 1; k++)
					for (int q = k+1; q<=cardinality; q++)
						printf("[%04d] %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q]);
			}
		}
		else if (i == 4) {
			for (int j = 1; j <= cardinality - 3; j++) {
				for (int k = j + 1; k <= cardinality - 2; k++)
					for (int q = k + 1; q <= cardinality - 1; q++)
						for (int m = q + 1; m <= cardinality; m++)
							printf("[%04d] %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m]);
			}
		}
		else if (i == 5) {
			for (int j = 1; j <= cardinality - 4; j++) {
				for (int k = j + 1; k <= cardinality - 3; k++)
					for (int q = k + 1; q <= cardinality - 2; q++)
						for (int m = q + 1; m <= cardinality - 1; m++)
							for (int n = m + 1; n <= cardinality; n++)
								printf("[%04d] %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n]);
			}
		}
		else if (i == 6) {
			for (int j = 1; j <= cardinality - 5; j++) {
				for (int k = j + 1; k <= cardinality - 4; k++)
					for (int q = k + 1; q <= cardinality - 3; q++)
						for (int m = q + 1; m <= cardinality - 2; m++)
							for (int n = m + 1; n <= cardinality - 1; n++)
								for (int w = n + 1; w <= cardinality; w++)
									printf("[%04d] %c, %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w]);
			}
		}
		else if (i == 7) {
			for (int j = 1; j <= cardinality - 6; j++) {
				for (int k = j + 1; k <= cardinality - 5; k++)
					for (int q = k + 1; q <= cardinality - 4; q++)
						for (int m = q + 1; m <= cardinality - 3; m++)
							for (int n = m + 1; n <= cardinality - 2; n++)
								for (int w = n + 1; w <= cardinality - 1; w++)
									for (int o = w + 1; o <= cardinality; o++)
										printf("[%04d] %c, %c, %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o]);
			}
		}
		else if (i == 8) {
			for (int j = 1; j <= cardinality - 7; j++) {
				for (int k = j + 1; k <= cardinality - 6; k++)
					for (int q = k + 1; q <= cardinality - 5; q++)
						for (int m = q + 1; m <= cardinality - 4; m++)
							for (int n = m + 1; n <= cardinality - 3; n++)
								for (int w = n + 1; w <= cardinality - 2; w++)
									for (int o = w + 1; o <= cardinality - 1; o++)
										for (int t = o + 1; t<= cardinality; t++)
											printf("[%04d] %c, %c, %c, %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o], *argv[t]);
			}
		}
		else if (i == 9) {
			for (int j = 1; j <= cardinality - 8; j++) {
				for (int k = j + 1; k <= cardinality - 7; k++)
					for (int q = k + 1; q <= cardinality - 6; q++)
						for (int m = q + 1; m <= cardinality - 5; m++)
							for (int n = m + 1; n <= cardinality - 4; n++)
								for (int w = n + 1; w <= cardinality - 3; w++)
									for (int o = w + 1; o <= cardinality - 2; o++)
										for (int t = o + 1; t <= cardinality - 1; t++)
											for (int e = t + 1; e <= cardinality; e++)
												printf("[%04d] %c, %c, %c, %c, %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o], *argv[t], *argv[e]);
			}
		}
		else if (i == 10) {
			for (int j = 1; j <= cardinality - 9; j++) {
				for (int k = j + 1; k <= cardinality - 8; k++)
					for (int q = k + 1; q <= cardinality - 7; q++)
						for (int m = q + 1; m <= cardinality - 6; m++)
							for (int n = m + 1; n <= cardinality - 5; n++)
								for (int w = n + 1; w <= cardinality - 4; w++)
									for (int o = w + 1; o <= cardinality - 3; o++)
										for (int t = o + 1; t <= cardinality - 2; t++)
											for (int e = t + 1; e <= cardinality - 1; e++)
												for (int r = e + 1; r <= cardinality; r++)
													printf("[%04d] %c, %c, %c, %c, %c, %c, %c, %c, %c, %c\n", num++, *argv[j], *argv[k], *argv[q], *argv[m], *argv[n], *argv[w], *argv[o], *argv[t], *argv[e], *argv[r]);
			}
		}
	}



	printf("|---*-*-*-*-*-*-*-*-*---|\n");
	printf("|                       |\n");
	printf("| 20190564   EomChanwoo |\n");
	printf("|                       |\n");
	printf("|---*-*-*-*-*-*-*-*-*---|");

	return 0;
}