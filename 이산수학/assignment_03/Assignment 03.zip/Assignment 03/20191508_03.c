#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define TRUE 1
#define FALSE 0

int newSubsetId = 1;
int elementsCnt;
char* elements;
typedef char bool;
void printAllSubsets(bool* existences, int step);
void printSubset(bool* existences);
int main(int argc, char* argv[])
{
	elementsCnt = argc - 1;
	if (elementsCnt == 0) {
		printSubset(NULL);
	}
	else {
		elements = (char*)malloc(sizeof(char) * elementsCnt);
		for (int i = 0; i < elementsCnt; i++)
			elements[i] = argv[i + 1][0];

		bool* existences = (bool*)malloc(sizeof(bool) * elementsCnt);
		printAllSubsets(existences, 0);
	}
	printf("\n");
	printf("==========================================================\n");
	printf("   _______     __  _ \n");
	printf("  / ____\\ \\   / / | |\n");
	printf(" | (___  \\ \\_/ /  | |\n");
	printf("  \\___ \\  \\   /   | |\n");
	printf("  ____) |  | | |__| |\n");
	printf(" |_____/   |_|\\____/ \n");
	printf("                     \n");
	printf("Name : Shin YeonJin\n");
	printf("Student Id: 20191508\n");
	printf("==========================================================");
}
void printAllSubsets(bool* existences, int step) {
	for (int i = FALSE; i <= TRUE; i++) {
		existences[step] = i;
		if (step == elementsCnt - 1) {
			printSubset(existences);
		}
		else {
			printAllSubsets(existences, step + 1);
		}
	}
}
void printSubset(bool* existences) {
	bool isEmptySet = TRUE, firstTime = TRUE;
	int subsetId = newSubsetId++;
	printf("[%04d] ", subsetId);
	for (int i = 0; i < elementsCnt; i++) {
		if (existences[i]) {
			if (!firstTime) {
				printf(", ");
			}
			printf("%c", elements[i]);
			firstTime = FALSE;
			isEmptySet = FALSE;
		}
	}
	if (isEmptySet) {
		printf("ø\n");
	}
	else {
		printf("\n");
	}
}