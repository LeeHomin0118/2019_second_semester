#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int j = 1;

int powerset(int count_i, int count_p, int element, int *flag, char *argv[], char **ans){
	//공집합일 경우(항상 가장 마지막) 공집합 기호 출력하도록
	if (j == count_p){
		//printf("[%04d] %c\n", j, 155);
		return 0;
	}
	
	if (count_i == element){
		int i;
		//printf("[%04d] ", j);
		for(i = 1; i < count_i; i++){
            if(flag[i] == 1) 
				strcat(ans[j] ,argv[i]);
        }
        //printf("%s\n", ans[j]);
		j++;
        return 0;
    }
	
	flag[element] = 1;
	powerset(count_i, count_p, element + 1, flag, argv, ans);
	flag[element] = 0;
	powerset(count_i, count_p, element + 1, flag, argv, ans);
}	

int main(int argc, char *argv[]){
	int i, k;
	int count_i = 0;	//number of input
	int count_p = 1;	//number of powerset
	int *flag;			//for 원소 선택 유무 check
	char **ans;			//부분집합 원소 집어 넣을 이차원 배열
	
	argc = 11;
	
	for (i = 1; argv[i]; i++){
		count_i++;
	}
	
	flag = (int *)calloc(11, sizeof(int));
	
	ans = (char **)calloc(11, sizeof(char *));
	for (i = 0; i < 11; i++){
		ans[i] = (char *)calloc(30, sizeof(char));
	}
	
	//number of powerset's elements
	for (i = 0; i < count_i; i++){
		count_p *= 2;
	}
	
	powerset(count_i + 1, count_p, 1, flag, argv, ans);
	
	printf("[%04d] %c\n", 1, 155);
	
	for (i = 1; i < count_p; i++){
		printf("[%04d] ", i + 1);
		int c = strlen(ans[i]);
		for (k = 0; k < c - 1; k++){
		printf("%c, ", ans[i][k]);
		//printf("%s \n", ans[i]);
		}
		printf("%c", ans[i][c-1]);
		puts("");
	}
	
	printf("--@*'-'*@--------\n");
	printf("YouKyeong Kang\n");
	printf("20172051, CAU\n");
	printf("--------@*'-'*@--\n");
	
	return 0;
	
}