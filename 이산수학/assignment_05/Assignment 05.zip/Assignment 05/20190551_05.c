#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>


int sumNumbers(int* pNumbers, int index, int total,char *fp2) {

	if (index == -1) return total;

	int number = pNumbers[index];
	total += number;
	fprintf(fp2,"[%03d] %d\n", index+1, total);

	total += sumNumbers(pNumbers, index - 1, total,fp2);
}



int main(int argc, char* argv[])
{
	FILE* fp1, * fp2;

	char str[20];



	if ((fp1 = fopen(argv[1], "r")) == NULL) {
		printf("fail to open file.");
		return 0;
	}
	if ((fp2 = fopen(argv[2], "wt")) == NULL) { 
		printf("fail to create file for write.");
		return 0;
	}

	int flag = 0;
	int* pNumbers = NULL;
	int index = 0;
	int size = 0;

	while (fgets(str, sizeof(str), fp1)) {  
		
		int num = atoi(str);
		
		if (flag == 0) {
			size = num;
			pNumbers = (int*)malloc(sizeof(int)*num);
			flag++;
		}
		else {
			pNumbers[index] = num;
			index++;
		}
				
	}
	

	sumNumbers(pNumbers, size-1, 0,fp2);
	fprintf(fp2, "----------------------!!!!!!\n");
	fprintf(fp2, "Hyo Chang Yoo\n");
	fprintf(fp2, "Student ID : 20190551\n");
	fprintf(fp2, "----------------------!!!!!!\n");

	fclose(fp1);
	fclose(fp2);

	return 0;
}
