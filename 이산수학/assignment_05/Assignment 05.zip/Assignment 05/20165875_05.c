#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LOG_BUFFER_SIZE 32768

int g_nNumber = 0;
char g_logBuffer[LOG_BUFFER_SIZE] = { 0, };

void Log( char* message )
{
    sprintf( g_logBuffer + strlen( g_logBuffer ), "%s", message );
}

void PrintSigniture()
{
    Log( "************************\n" );
    Log( "Eun-Kyu Lim\n" );
    Log( "Stundent ID : 20165875\n" );
    Log( "************************\n" );
}

void ProcessOutput( const char* filePath )
{
   
    printf( "%s", g_logBuffer );
    

    FILE* fileToWrite = fopen( filePath, "wt" );
    if( NULL == fileToWrite )
    {
        printf( "fail to create file for write - %s", filePath );
        return;
    }

    fputs( g_logBuffer, fileToWrite );
    fclose( fileToWrite );
}



int sumNumbers( int* pNumbers, int nIndex, int result )
{
    if( 0 == nIndex )
    {
        return result;
    }
    
    int summedResult = pNumbers[nIndex - 1] + result;

    char buffer[32];
    sprintf( buffer, "[%03d] %d\n", nIndex, summedResult );
    Log( buffer );
    
    return sumNumbers( pNumbers, nIndex - 1, summedResult );
}

int main( int argc, char * argv[] )
{
    char* filePathToRead = argv[1];
    char* filePathToWrite = argv[2];
    
    FILE *fp;
    if( ( fp = fopen( filePathToRead, "r" ) ) == NULL )
    {
        printf( "fail to open file.\n" );
        return 0;
    }
    

    char str[64];
    fgets( str, sizeof( str ), fp );
    g_nNumber = atoi( str );
    
    if( g_nNumber > 100 )
    {
 
        Log( "Error: We do not support numbers bigger than 100\n" );
    }
    else
    {
      
        int* pNumbers = ( int* )calloc( g_nNumber, sizeof( int ) );
        
   
        for( int i = 0; i < g_nNumber; i++ )
        {
            fgets( str, sizeof( str ), fp );
            pNumbers[i] = atoi( str );
        }
        
        
        int sum = sumNumbers( pNumbers, g_nNumber, 0 );
        printf( "%d\n", sum );
        
        free( pNumbers );
    }
    
 
    PrintSigniture();
    
  
    ProcessOutput( filePathToWrite );
    
    return 0;
}
