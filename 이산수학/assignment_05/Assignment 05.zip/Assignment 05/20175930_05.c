#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int data[100];
int sumNumbers (int result, int n)
{

	if(n ==0) return data[n];
	else return (data[n] + sumNumbers (data[n-1], n - 1));
	
}
	

int main (int argc, char  * argv[]) {

	FILE *fp1, *fp2;
	int k =0;
	int i;
	int text[100];
	int cnt;

	fp1 = fopen(argv[1], "r");

	while (fscanf(fp1, "%d", &i) != EOF) {
		text[k] = i;
		k++;
	}
	
	fclose(fp1);

	for(int i =0; i < text[0]; i++)
	{
		data[text[0]-i-1] = text[i+1];
	}
	
	fp2 = fopen(argv[2], "w");

	for(int n =0; n < text[0]; n++)
	{
		fprintf(fp2, "[%03d] %d \n", (text[0]-n) ,sumNumbers(data[n], n));
	}
	
	fprintf(fp2,"******************* \n");
	fprintf(fp2,"김동규 \nStudent ID: 20175930\n");
	fprintf(fp2,"       *         \n");
	fprintf(fp2,"     * 28 *         \n");
	fprintf(fp2,"       *         \n");	
	fprintf(fp2,"$$$$$$$$$$$$$$$$$$$$ \n");
	fclose(fp2);

	return 0;
}

