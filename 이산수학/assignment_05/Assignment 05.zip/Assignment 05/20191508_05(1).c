﻿#define _CRT_SECURE_NO_WARNINGS
#include "stdio.h"

FILE* outputF;
int numberCount;
int sumNumbers(int* numbers, int index) {
	int sum;
	if (index == 0) {
		sum = numbers[0];
	}
	else {
		sum = numbers[index] + sumNumbers(numbers, index - 1);
	}
	fprintf(outputF, "[%03d] %d\n", numberCount - index, sum);
	return sum;
}
int main(int argc, char* argv[])
{
	FILE *inputF = fopen(argv[1], "r");
	outputF = fopen(argv[2], "w");

	if (inputF == NULL) {
		printf("Unable to read input file");
		return 1;
	}
	if (outputF == NULL) {
		printf("Unable to write output file");
		return 1;
	}

	const int bufSize = 64;
	char* buf = (char*)(malloc(sizeof(char) * bufSize));

	fgets(buf, 64, inputF);
	sscanf(buf, "%d", &numberCount);
	int* numbers = (int*)(malloc(sizeof(int) * numberCount));
	for (int i = numberCount - 1; i >= 0; i--) {
		fgets(buf, 64, inputF);
		sscanf(buf, "%d", numbers + i);
	}

	sumNumbers(numbers, numberCount - 1);
	fprintf(outputF, "=====================\n");
	fprintf(outputF, " .----..-.  .-.  .-.\n");
	fprintf(outputF, "{ {__   \ \/ /.-.| |\n");
	fprintf(outputF, ".-._} }  }  { | {} |\n");
	fprintf(outputF, "`----'   `--' `----'\n");
	fprintf(outputF, "\n");
	fprintf(outputF, "Yeonjin Shin\n");
	fprintf(outputF, "Student ID : 20191508\n");
	fprintf(outputF, "=====================\n");
}