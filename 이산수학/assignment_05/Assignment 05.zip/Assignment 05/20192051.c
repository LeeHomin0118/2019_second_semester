#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h> 

int kim = 0;
int kim_i = 0;

int sumNumbers(int* number, int nIndex, FILE* fp2)
{
	char temp_str[64];
	int sum = 0;
	// basis step
	if (nIndex <= 0)
	{
		return number[0];
	}
	// recursive step

 //   else
 //   {
 //
 //      sum = number[nIndex] + sumNumbers(number, nIndex - 1);
 //      
 //      return sum;
 //
 //   }

	else
	{
		kim_i--;
		//   printf("%d %d\n", sum, kim);
		sprintf(temp_str, "[%03d] %d\n", kim_i, kim);
		fputs(temp_str, fp2);
		//kim�� ���ؼ� ����Լ� ���̿� ���ǿ� �°� ������ �̷�������� ���� ����մϴ�.
		kim = kim + number[nIndex - 1];
		//sum�� ����Լ��� ��Ÿ���ϴ�.
		sum = number[nIndex] + sumNumbers(number, nIndex - 1, fp2);
		//   printf("%d %d\n", sum, kim);

		return sum;
	}
}


int main(int argc, char* argv[]) {


	FILE* fp1, * fp2;
	char str[64];   // change the number appropriately to your program

	char temp_str[64];
	int temp_number;
	// read_file = argv[1]
	// write_file = argv[2]

	// see the usage of r, rt, w, wt, r+, w+
  //   if ((fp1 = fopen(argv[1], "r")) == NULL) { //fail to open file for read
	if ((fp1 = fopen(argv[1], "r")) == NULL) { //�����
		printf("fale to open file.");
		return 0;
	}
	//   if ((fp2 = fopen(argv[2], "wt")) == NULL) { //fail to open file for write
	if ((fp2 = fopen(argv[2], "wt")) == NULL) { //�����
		printf("fail to create file for write.");
		return 0;
	}



	int Nnumber;
	int number[100];
	int i = 0;

	fgets(str, sizeof(str), fp1);
	sprintf(temp_str, "%s", str);
	temp_number = atoi(temp_str);

	Nnumber = temp_number;
	kim_i = temp_number + 1;
	//�����
	//sprintf(temp_str, "%d\n", temp_number + 1);
	//fputs(temp_str, fp2);

	while (fgets(str, sizeof(str), fp1)) {
		number[i] = atoi(str);
		i++;
	}
	//������
	/*
	while (fgets(str, sizeof(str), fp1)) {   // read a file and write to another file line by line
	   //sprintf(str, "%s\n", str);
	   fputs(str, fp2);
	}
	*/




	//
	// recursive sum
	//nNumber�� Nnumber�� ��ü, ������ pNumbers�� �迭 number�� ��ü�ߴ�.
	/*
	int     nNumber = 10;   // read from the input file
	int* pNumbers = (int*)calloc(nNumber, sizeof(int));

	for (int i = 0; i < nNumber; i++)
	{
	   pNumbers[i] = 1;        // assign numbers from the input file
	}
	*/
	kim = number[Nnumber - 1];

	int     nSum = sumNumbers(number, Nnumber - 1, fp2);


	kim_i--;

	sprintf(temp_str, "[%03d] %d\n", kim_i, nSum);
	fputs(temp_str, fp2);

	//������ pNumbers�� �迭 number�� ��ü�ϸ� ������� �ʴ´�.
	//free(pNumbers);
	//

	fputs("---------------------------------------------------------\n", fp2);
	fputs("l                CHUNG.ANG UNIVERSITY.SINCE1918 l\n", fp2);
	fputs("l ������  ������                          /@@@@ib   l\n", fp2);
	fputs("l ������  ����Ʈ�������            @@@@@@b  l\n", fp2);
	fputs("l ������  20192051                   D...----.__.----...D l\n", fp2);
	fputs("l         Seon JiHoon                   l  ---^  ^---  l  l\n", fp2);
	fputs("l   CAU                                     b    -v-   d     l\n", fp2);
	fputs("l �߾Ӵ��б�                                   -.__.-        l\n", fp2);
	fputs("---------------------------------------------------------\n", fp2);


	fclose(fp1);
	fclose(fp2);
	return 0;
}