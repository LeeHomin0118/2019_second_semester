#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int sum(int *pNum, int index) {
	int result;

	if (index == 1)
		result = *pNum;
	else
		result = *(pNum + index - 1) + sum(pNum, index - 1);

	return result;
}


int main(int *argc, char *argv[]) {
	FILE *inputFile, *outputFile;

	if ((inputFile = fopen(argv[1], "r")) == NULL) {
		printf("Fail to open file.");
		return 0;
	}

	if ((outputFile = fopen(argv[2], "w")) == NULL) {
		printf("Fail to create file for write.");
		return 0;
	}

	int nNum, *pNum;
	fscanf(inputFile, "%d", &nNum);
	pNum = (int*)calloc(nNum, sizeof(int));

	for (int i = 0; i < nNum; i++) {
		fscanf(inputFile, "%d", &pNum[i]);
	}

	const int SUM = sum(pNum, nNum);

	for (int i = nNum; i > 0; i--) {
		if (i > 1)
			fprintf(outputFile, "[%03d] %d\n", i, SUM - sum(pNum, i - 1));
		else if (i == 1)
			fprintf(outputFile, "[%03d] %d\n", i, SUM);
	}

	free(pNum);

	fprintf(outputFile, "|---*-*-*-*-*-*-*-*-*---|\n");
	fprintf(outputFile, "|                          |\n");
	fprintf(outputFile, "| 20190564   EomChanwoo |\n");
	fprintf(outputFile, "|                          |\n");
	fprintf(outputFile, "|---*-*-*-*-*-*-*-*-*---|");

	fclose(inputFile);
	fclose(outputFile);

	return 0;
}