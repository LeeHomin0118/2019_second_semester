#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//이 함수는 index가 1이 될 때까지만 돌아야함. index가 0인 경우는 입력 count 수이기 때문.
int sumNumbers(int count, int index, int *arr, FILE *fp2, int sum){

	if (index == 0) return 0;
	
	//basis step : 첫 index 경우의 sum 값 (여기선 거꾸로 더하기 때문에 마지막 index일 경우임)
	if (index >= count)
		sum = arr[index];
	
	//recursive step : index n의 sum이 성립하면 n+1의 sum 역시 성립 -> 기존의 sum 값(index+1의 sum값)을 불러와 거기에 다음 index(index) 값을 더해준다.
	else 
		sum += arr[index];
	
	fprintf(fp2, "[%03d] %d\n", index, sum);
	sumNumbers(count, index - 1, arr, fp2, sum);

	return sum;
	
}

int main(int argc, char *argv[]){
	
	 FILE *fp1, *fp2;	//1 입력, 2 출력
	 
	 char str[30];
	 int count;			//입력 파일에서 입력 수 개수
	 int i;
	 int *arr;			//입력 파일의 숫자를 arr에 저장
	 int sum = 0;
		
	if((fp1=fopen(argv[1],"r"))  == NULL){
        printf("cannot open file1");
        return 0;
    }

	/*
    if((fp2=fopen(argv[2],"wt")) == NULL){
        printf("cannot open file2");
        return 0;
    }
	*/
	
	fp2 = fopen(argv[2], "w");
	
	if (fgets(str, sizeof(str), fp1) != NULL){
		count = atoi(str);
	}
	
	arr = (int *)calloc(count + 1, sizeof(int));
	
	i = 1;
	while (fgets(str, sizeof(str), fp1) != NULL){
		arr[i] = atoi(str);
		i++;
	}
	//여기까지 입력 파일의 모든 숫자를 int로 변환하여 arr에 저장
		
	sumNumbers(count, count, arr, fp2, sum);
	
	fputs("\n--@*'-'*@--------\n", fp2);
	fputs("YouKyeong Kang\n", fp2);
	fputs("20172051, CAU\n", fp2);
	fputs("--------@*'-'*@--\n", fp2);
	
	fclose(fp2);
	
	fp2 = fopen(argv[2], "r");
	
	while(fgets(str, sizeof(str), fp2) != NULL){
		printf("%s", str);
	}
	
	free(arr);
	
	fclose(fp1);
	fclose(fp2);
	
	return 0;
}
	
	

