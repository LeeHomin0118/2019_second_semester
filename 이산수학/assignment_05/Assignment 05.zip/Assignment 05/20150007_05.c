#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h> 

int sumNumbers(int* pNumbers, int nIndex,int nNumber,FILE *fp)
{
	// basis step
	if (nIndex <= 0)
	{
		fprintf(fp, "[%.3d] %d\n", nNumber+nIndex,pNumbers[0]);
		return pNumbers[0];
	}
	// recursive step
	else
	{
		int result = pNumbers[nIndex] + sumNumbers(pNumbers, nIndex - 1,nNumber,fp);
		fprintf(fp, "[%.3d] %d\n", nNumber - nIndex, result);
		return result;
	}
}


int main(int argc,char* argv[]) {

	FILE *fp1, *fp2;
	char str[64];   // change the number appropriately to your program
	// read_file = argv[1]
	// write_file = argv[2]
	// see the usage of r, rt, w, wt, r+, w+
	if ((fp1 = fopen(argv[1], "r")) == NULL) { //fail to open file for read
		printf("fale to open file.");
		return 0;
	}
	if ((fp2 = fopen(argv[2], "wt")) == NULL) { //fail to open file for write
		printf("fail to create file for write.");
		return 0;
	}
	int nNumber = 0;
	fgets(str, sizeof(str), fp1);
	nNumber = atoi(str);   // read from the input file
	int*    pNumbers = (int*)calloc(nNumber, sizeof(int));
	int i = 1;
	while (fgets(str, sizeof(str), fp1)) {   // read a file and write to another file line by line
		pNumbers[nNumber-i] = atoi(str);
		i++;
	}



	int nSum = sumNumbers(pNumbers, nNumber-1,nNumber,fp2);
	free(pNumbers);
	fputs("---------CopyRight AhnSeungJae----------------\n", fp2);
	fputs("Student ID: 20150007\n", fp2);
	fputs("Ahn SeungJae\n", fp2);
	fputs("---------don't copy my Code-----------------\n", fp2);
	//

	fclose(fp1);
	fclose(fp2);
	return 0;
}
