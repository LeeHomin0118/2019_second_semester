//
//  main.c
//  math05
//
//  Created by 王志鹏 on 06/11/2019.
//  Copyright © 2019 wangzhipeng. All rights reserved.
//

#include <stdio.h>
#include<stdlib.h>
int d,i;
int main()
{
     
    FILE*fp1;
    fp1=fopen("/Users/wangzhipeng/20191806-5 input.txt","w");
    if(fp1==NULL){
        printf("fale to open file.");
    }else{
        scanf("%i", &d);
        for (i=1;i<=d;i++)
          {
           fprintf(fp1,"%i\n",i);
              fclose(fp1);
          }
         }
    FILE*fp2;
    int sumnumbers;
    fp1=fopen("/Users/wangzhipeng/20191806-5 input.txt","r");
    fp2=fopen("/Users/wangzhipeng/20191806-5 output.txt","w");
    if (fp2==NULL){
        printf("fale to write file.");
    }
    else{
    for(i=d;i>0;i--){
        sumnumbers +=i;
        fprintf(fp2,"[%03i] %i\n",i,sumnumbers);
        
    }
    }
    fprintf(fp2,"$$$$$$$$$$$$$$$$$$$$\n");
    fprintf(fp2,"$$$$$$$wang$$$$$$$$$\n");
    fprintf(fp2,"$$$$zhi$$$$$peng$$$$\n");
    fprintf(fp2,"$$$$ id:20191806 $$$\n");
    fprintf(fp2,"$$$$$$$$$$$$$$$$$$$$\n");
        fclose(fp1);
        fclose(fp2);
    return 0;
    }

