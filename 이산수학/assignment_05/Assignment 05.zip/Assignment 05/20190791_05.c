#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int sumNumbers(int* pNumbers, int nIndex)
{
	int result;
	if (nIndex == 1)
		result = *pNumbers;
	else
		result = *(pNumbers + nIndex - 1) + sumNumbers(pNumbers, nIndex - 1);
	return result;
}

int main(int argc, char* argv[])
{
	FILE* fp1, * fp2;

	if ((fp1 = fopen(argv[1], "r")) == NULL)
	{
		printf("fail to open file.");
		return 0;
	}
	if ((fp2 = fopen(argv[2], "wt")) == NULL)
	{
		printf("fail to create file for write.");
		return 0;
	}

	int nNumber;
	fscanf_s(fp1, "%d", &nNumber);
	int* pNumbers = (int*)calloc(nNumber, sizeof(int));

	int i;
	for (i = 0; i < nNumber; i++) {
		fscanf_s(fp1, "%d", &pNumbers[i]);
	}

	const int sum = sumNumbers(pNumbers, nNumber);
	
	for (i = nNumber; i > 0; i--) {
		if (i > 1)
			fprintf(fp2, "[%03d] %d\n", i, sum - sumNumbers(pNumbers, i - 1));
		else if (i == 1)
			fprintf(fp2, "[%03d] %d\n", i, sum);
	}

	free(pNumbers);

	fprintf_s(fp2, "�� �й��� 20190791�Դϴ�!!\n");
	fprintf_s(fp2, "�� �̸��� ���ȯ�Դϴ�!!\n");
	fclose(fp1);
	fclose(fp2);
	return 0;
}