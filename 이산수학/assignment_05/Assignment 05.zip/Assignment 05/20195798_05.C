#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>

int main()
{
	FILE* fp;
	FILE* fp1;
	char str[100];
	int trianglarN = 0;

	char a = 0, n,

		fp = fopen("C:\\Users\\Kiang\\Desktop\\20195798yang\\output.txt", "w");
	fp1 = fopen("C:\\Users\\Kiang\\Desktop\\20195798yang\\input.txt", "r");
	if (fp == NULL)
	{
		printf("fale to open file.");
		return -1;

	}
	if (fp1 == NULL)
	{
		printf("fale to read file.");
		return -1;
	}
	else
	{
		while (fscanf_s(fp1, "%d", &str[a]) != EOF)
			i++;
		for (i = 12; i > 0; i--)
		{
			str[a] += i;

			fprintf(fp, "[%03d]  %i\n", i, str[a]);
		}
	}
	fprintf(fp, "*****************************\n");
	fprintf(fp, "Yang HaoChen\n");
	fprintf(fp, "Student ID:20195798\n");
	fprintf(fp, "*****************************\n");

	fclose(fp);
	fclose(fp1);

	return 0;
}