﻿#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>

//사용자 정의 함수
int strtoint(char str[]);	//문자열 int화
int SumNumber(FILE *read_fp, FILE *write_fp, int total, int index, int *presult);	//숫자합 반환 + 파일 입력 재귀함수

int main(int argc, char *argv[]) {
	FILE *fp1, *fp2;
	char str[5];	//index 받을 문자열
	// read_file = argv[1]
	// write_file = argv[2]
	int index, result = 0;
	int *presult = &result;

	fp1 = fopen(argv[1], "r");
	fp2 = fopen(argv[2], "wt");

	if (fp1 == NULL) {
		printf("fail to open file.");
		return 0;
	}

	if (fp2 == NULL) {
		printf("fail to create file for write.");
		return 0;
	}

	fgets(str, sizeof(str), fp1);
	index = strtoint(str);

	SumNumber(fp1, fp2, index, index, presult);

	//Signiture
	fprintf(fp2, "\n");
	fprintf(fp2, "           o ,, o        ___________________________\n");
	fprintf(fp2, "    ,,＿(    '″'  )   ,,  |                                  |\n");
	fprintf(fp2, "    )　 　      |￣/ <  Kim Hee - min            |\n");
	fprintf(fp2, "   /　   　    / /    |                                  |\n");
	fprintf(fp2, " /__　    __ __/      |  Student ID : 20195535  |\n");
	fprintf(fp2, " “   /　|　  ”        |____________________________|\n");
	fprintf(fp2, "    /　 |\n");
	fprintf(fp2, "   (___ /\n");
	fprintf(fp2, "\n");


	fclose(fp1);
	fclose(fp2);

	return 0;
}

//문자열 int화
int strtoint(char str[]) {
	int i = 0;
	int num = 0;

	while (str[i] && str[i] != '\n') {//str[i] == 0 or str[i] == '\n'이면 stop
		num = num * 10 + str[i] - '0';

		i++;
	}

	return num;
}

//숫자합 반환 + 파일 입력 재귀함수
int SumNumber(FILE *read_fp, FILE *write_fp,int total, int index, int *presult) {
	char str[12];	//txt 한 줄 저장 문자열

	//Basis step
	if (index == 1) {
		fgets(str, sizeof(str), read_fp);	//한 줄 읽어옴
		*presult += strtoint(str);	//문자열 int화 함수, presult는 main에서 선언

		fprintf(write_fp, "[%03d] %d\n", total, *presult);	// File에 출력

		return *presult;
	}
	//Reculsive step
	else{
		fgets(str, sizeof(str), read_fp);	//한 줄 읽어옴

		SumNumber(read_fp, write_fp, total, index - 1, presult);	//재귀

		*presult += strtoint(str);	//문자열 int화 함수

		fprintf(write_fp, "[%03d] %d\n", (total + 1) - index, *presult);	// File에 출력

		return *presult;
	}

}