#include <stdio.h>
#include <ctype.h>

int RecursiveSum(int*, int, FILE *);

int main(int argc, char* argv[])
{
	FILE *fpi = fopen(argv[1], "rt");
	FILE *fpo = fopen(argv[2], "wt");
	
	char *str[50];
	
	int n = atoi(fgets(str, sizeof(str), fpi));
	
	int arr[n];
	
	for (int i = 0; i < n; i++)
	{
		arr[i] = atoi(fgets(str, sizeof(str), fpi));
	}
	
	RecursiveSum(arr, n, fpo);	
		
	/*           signiture           */
	fputs("�ɢǢǢǢǢǢǢǢǢ�\n", fpo);
	fputs("��                ��\n", fpo);
	fputs("�� 20196261  �Ӱ� ��\n", fpo);
	fputs("��                ��\n", fpo);	
	fputs("�ʢǢǢǢǢǢǢǢǢ�\n", fpo); 
	/*           signiture           */
	
	fclose(fpi);
	fclose(fpo);
	
	return 0;	
}

int RecursiveSum(int *arr, int n, FILE *fpo)
{
	static int sum = 0;
	
	if (n == 0)
	{
		return 0;
	}
	else
	{
		sum += arr[n - 1];
		fprintf(fpo, "[%03d] %d\n", n, sum);
		return arr[n - 1] + RecursiveSum(arr, n - 1, fpo);
	}
}
