#include <stdio.h>
#include <stdlib.h>
#pragma warning(disable:4996)

int sumNumbers(int * pNumbers, int nIndex, FILE*fp)
{
	if (nIndex > 1)
	{
		printf("[%03d] %d\n", nIndex, pNumbers[nIndex - 1]);
		fprintf(fp, "[%03d] %d\n", nIndex, pNumbers[nIndex - 1]);
		pNumbers[nIndex - 2] += pNumbers[nIndex - 1];
		return sumNumbers(pNumbers, --nIndex,fp);
	}
	else
	{
		printf("[%03d] %d\n", nIndex, pNumbers[nIndex - 1]);
		fprintf(fp, "[%03d] %d\n", nIndex, pNumbers[nIndex - 1]);
		return pNumbers[nIndex - 1];
	}
}
int main(int argc, char* argv[])
{
	FILE *fp1, *fp2;
	char str[64];
	int a;
	int sum = 0;
	int i = 0;
	fp1 = fopen(argv[1], "rt");
	fp2 = fopen(argv[2], "wt");
	if (fp1 == NULL)
	{
		printf("fail to open file.");
		return -1;
	}
	if (fp2 == NULL)
	{
		printf("fail to creat file for write.");
		return -1;
	}
	a = atoi(fgets(str, sizeof(str), fp1));
	int * pnumbers = malloc(sizeof(int)*a);
	while ( i < a)
	{
		fgets(str, sizeof(str), fp1);
		pnumbers[i] = atoi(str);
		i++;
	}
	sumNumbers(pnumbers, a,fp2);
	printf("---------------------\nName : Kim Namju\nStudent Id : 20190270\n---------------------");
	free(pnumbers);
	fclose(fp1);
	fclose(fp2);
	return 0;
}