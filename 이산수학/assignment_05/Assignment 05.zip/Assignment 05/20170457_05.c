#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h> 

int sumNumbers(int* pNumbers, int nIndex, FILE *file) 
{   
    static int sum = 0;

    // basis step
    if( nIndex <= 0)
    {   
        return sum;
    }
    // recursive step
    else
    {   
        sum += pNumbers[nIndex - 1];
        fprintf(file, "[%03d] %d\n", nIndex, sum);

        return sumNumbers(pNumbers, (nIndex - 1), file);
    }
}
 

int main(int argc, char* argv[]){

    FILE *fp1, *fp2;
    int nNumber;
    // read_file = argv[1]
    // write_file = argv[2]

    // see the usage of r, rt, w, wt, r+, w+
    if((fp1=fopen(argv[1],"r"))  == NULL){ //fail to open file for read
        printf("fail to open file.\n");
        exit(1);
    }
    if((fp2=fopen(argv[2],"wt")) == NULL){ //fail to open file for write
        printf("fail to create file for write.\n");
        exit(1);
    }

    fscanf(fp1, "%d", &nNumber);

    if (nNumber > 100) {
        printf("Error! The maximum number is 100.\n");
        exit(1);
    }

    int* pNumbers = (int*) calloc(nNumber, sizeof(int));

    for(int i = 0; i < nNumber; i++)
    {   
        fscanf(fp1, "%d", &pNumbers[i]);       // assign numbers from the input file 
    }
    
    int nSum = sumNumbers(pNumbers, nNumber, fp2);

    printf("%d\n", nSum);

    //signature
    fprintf(fp2, " _______________________________\n|                               |\n|                               |\n| '-') { 20170457 Isabella )    |\n -------------------------------\n");

    free(pNumbers);
    
    fclose(fp1);
    fclose(fp2);

    return 0;
}