//
//  main.c
//  ruoci018
//
//  Created by 王志鹏 on 04/11/2019.
//  Copyright © 2019 wangzhipeng. All rights reserved.
//


#include <stdio.h>
#include<stdlib.h>
int main(){
    FILE *fp1;
    char ch;
    int i;
    fp1=fopen("/Users/wangzhipeng/20191806-input.txt","w");
    if(fp1==NULL){
        printf("fale to open file.");

    }else
    {
        for(i=1;i<14;i++){
            fprintf(fp1,"%d\n",i);
          
        }
    }
    FILE*fp2;
    char str[64];
    int sum;
    fp1=fopen("/Users/wangzhipeng/20191806-input.txt","r");
    fp2=fopen("/Users/wangzhipeng/20191806-output.txt","wt");
    if(fp2==NULL){
        printf("fale to open file to write.");
    }
    else{
        for(i=14;i>0;i--){
           sum +=i;
            fprintf(fp2,"[%03i]  %i\n",i,sum);
        }
    }

    fprintf(fp2,"*******************\n");
    fprintf(fp2,"*******wang********\n");
    fprintf(fp2,"**zhi********peng**\n");
    fprintf(fp2,"******20191806*****\n");
    fprintf(fp2,"*dont copy my code*\n");
    fprintf(fp2,"****thank***you****\n");
    fprintf(fp2,"*******************\n");
    
    fclose(fp1);
    fclose(fp2);
    return 0;

    
    
    
    
}
