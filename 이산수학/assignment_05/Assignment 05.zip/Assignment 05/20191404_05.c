#include <stdio.h>
#include <stdlib.h>

int sum(FILE* f_out, int* arr, int n, int m);
void signature(FILE *f_out);

int main(int argc, char** argv)
{
    FILE *f_in, *f_out;
    int n;
    int* arr;

    f_in = fopen(argv[1], "r");
    f_out = fopen(argv[2], "w");

    fscanf(f_in, "%d", &n);
    
    arr = calloc(n, sizeof(int));

    for (int i = 0; i < n; i++) {
        fscanf(f_in, "%d", &arr[i]);
    }

    sum(f_out, arr, n, n);

    signature(f_out);

    free(arr);

    fclose(f_in);
    fclose(f_out);
}

int sum(FILE* f_out, int* arr, int n, int m)
{
    if (n == 1) {
        fprintf(f_out, "[%03d] %d\n", m - n + 1, arr[m - n]);
	return arr[m - n];
    } else {
	int s = sum(f_out, arr, n - 1, m) + arr[m - n];
	fprintf(f_out, "[%03d] %d\n", m - n + 1, s);
	return s;
    }
}


void signature(FILE* f_out)
{
    fprintf(f_out, "\n");
    fprintf(f_out, "********************************\n");
    fprintf(f_out, "*                              *\n");
    fprintf(f_out, "* Name       : Park Younghyeon *\n");
    fprintf(f_out, "* Student ID : 20191404        *\n");
    fprintf(f_out, "*                              *\n");
    fprintf(f_out, "*      00000        00000      *\n");
    fprintf(f_out, "*     0     0      0     0     *\n");
    fprintf(f_out, "*    0     0 0    0     0 0    *\n");
    fprintf(f_out, "*    0    0  0    0    0  0    *\n");
    fprintf(f_out, "*    0   0   0    0   0   0    *\n");
    fprintf(f_out, "*    0  0    0    0  0    0    *\n");
    fprintf(f_out, "*    0 0     0    0 0     0    *\n");
    fprintf(f_out, "*     0     0      0     0     *\n");
    fprintf(f_out, "*      00000        00000      *\n");
    fprintf(f_out, "*                              *\n");
    fprintf(f_out, "********************************\n");
}
