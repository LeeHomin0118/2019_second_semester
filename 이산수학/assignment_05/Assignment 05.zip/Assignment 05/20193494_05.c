#include <stdio.h>
#include <stdlib.h> 
#include <string.h>

int ftoi(FILE *fp1) {
	char str[64];
	fgets(str, 64, fp1);
	str[strlen(str)] = '\0';
	return atoi(str);
}

int sumNumbers(int	*pNumbers, int nIndex, FILE *fp2)
{
	int sum = 0;
	if (nIndex <= 0) {
		return 0 ;
	}
	// recursive step
	else {
		int a = pNumbers[nIndex-1] + sumNumbers(pNumbers, nIndex - 1, fp2);
		fprintf(fp2, "[%02d] %d\n", sizeof(pNumbers)*4-nIndex  , a);
		return a;
	}

}




int main(int argc, char* argv[]) {

	FILE *fp1, *fp2;
	char str[64];


	if ((fp1 = fopen(argv[1], "r")) == NULL) { //fail to open file for read
		printf("fale to open file.");
		return 0;
	}
	if ((fp2 = fopen(argv[2], "wt")) == NULL) { //fail to open file for write
		printf("fail to create file for write.");
		return 0;
	}

	int nNumber = ftoi(fp1);

	int *pNumbers = (int *)malloc(nNumber * sizeof(int));

	for (int i = 0; i < nNumber; i++) {
		if (fgets(str, 64, fp1) != NULL) {
			str[strlen(str)] = '\0';
			pNumbers[i] = atoi(str);
		}
	}

	sumNumbers(pNumbers, nNumber, fp2);

	free(pNumbers);

	fprintf(fp2, "\n*************************\n*  I'm Seo Hyeong Moon! *\n*        Hi Hello       *\n*************************");


	fclose(fp1);
	fclose(fp2);
	return 0;
}
